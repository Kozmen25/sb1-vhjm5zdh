import { View, Text, StyleSheet } from 'react-native';
import { useAuthContext } from '../../src/components/AuthProvider';

export default function ProfileScreen() {
  const { user } = useAuthContext();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profilim</Text>
      {user && (
        <Text style={styles.email}>{user.email}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f3f4f6',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  email: {
    fontSize: 16,
    color: '#6b7280',
  },
});