import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Driver = Database['public']['Tables']['drivers']['Row'];

export function useDrivers() {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDrivers();
  }, []);

  async function fetchDrivers() {
    try {
      const { data, error } = await supabase
        .from('drivers')
        .select('*, users(full_name, email)')
        .eq('available', true);

      if (error) throw error;
      setDrivers(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function getDriverById(id: string) {
    try {
      const { data, error } = await supabase
        .from('drivers')
        .select('*, users(full_name, email)')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return null;
    }
  }

  return {
    drivers,
    loading,
    error,
    getDriverById,
  };
}