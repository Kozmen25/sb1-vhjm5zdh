import { useState } from 'react';
import { supabase } from '../lib/supabase';

interface VehicleAnalytics {
  total_bookings: number;
  total_revenue: number;
  total_hours_rented: number;
  average_rating: number;
  monthly_stats: Array<{
    month: string;
    bookings: number;
    revenue: number;
    hours_rented: number;
  }>;
}

export function useVehicleAnalytics() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getVehicleAnalytics = async (vehicleId: string): Promise<VehicleAnalytics | null> => {
    setLoading(true);
    try {
      const { data, error: rpcError } = await supabase
        .rpc('get_vehicle_analytics', {
          p_vehicle_id: vehicleId
        });

      if (rpcError) throw rpcError;
      return data;
    } catch (err) {
      console.error('Error fetching vehicle analytics:', err);
      setError('Araç istatistikleri yüklenirken bir hata oluştu');
      return null;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    getVehicleAnalytics
  };
}