import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { stripe } from '../lib/stripe';

interface Payment {
  id: string;
  booking_id: string;
  amount: number;
  currency: string;
  status: string;
  stripe_payment_intent_id: string;
  stripe_client_secret: string;
  created_at: string;
  updated_at: string;
}

export function usePayments() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createPayment = async (bookingId: string, amount: number) => {
    setLoading(true);
    setError(null);

    try {
      // Create a payment intent on your server
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          booking_id: bookingId,
          amount,
          currency: 'try'
        }),
      });

      const { clientSecret, paymentIntentId } = await response.json();

      // Create payment record in Supabase
      const { data: payment, error: dbError } = await supabase
        .rpc('create_payment', {
          p_booking_id: bookingId,
          p_amount: amount,
          p_currency: 'try',
          p_stripe_payment_intent_id: paymentIntentId,
          p_stripe_client_secret: clientSecret
        });

      if (dbError) throw dbError;

      return {
        paymentId: payment,
        clientSecret
      };
    } catch (err) {
      console.error('Error creating payment:', err);
      setError('Ödeme başlatılırken bir hata oluştu');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const confirmPayment = async (clientSecret: string, paymentId: string) => {
    setLoading(true);
    setError(null);

    try {
      if (!stripe) throw new Error('Stripe yüklenemedi');

      const { error: stripeError } = await stripe.confirmCardPayment(clientSecret);

      if (stripeError) {
        await supabase.rpc('update_payment_status', {
          p_payment_id: paymentId,
          p_status: 'failed'
        });
        throw stripeError;
      }

      // Update payment status in database
      const { error: dbError } = await supabase.rpc('update_payment_status', {
        p_payment_id: paymentId,
        p_status: 'succeeded'
      });

      if (dbError) throw dbError;

      return true;
    } catch (err) {
      console.error('Error confirming payment:', err);
      setError('Ödeme onaylanırken bir hata oluştu');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const getPaymentsByBookingId = async (bookingId: string): Promise<Payment[]> => {
    try {
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .eq('booking_id', bookingId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (err) {
      console.error('Error fetching payments:', err);
      return [];
    }
  };

  return {
    loading,
    error,
    createPayment,
    confirmPayment,
    getPaymentsByBookingId
  };
}