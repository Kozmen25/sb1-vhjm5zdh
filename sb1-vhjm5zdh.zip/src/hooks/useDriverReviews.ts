import { useState } from 'react';
import { supabase } from '../lib/supabase';

interface DriverReview {
  id: string;
  booking_id: string;
  reviewer_id: string;
  driver_id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer: {
    full_name: string;
  };
}

interface ReviewStats {
  total_reviews: number;
  average_rating: number;
  rating_distribution: {
    '5': number;
    '4': number;
    '3': number;
    '2': number;
    '1': number;
  };
}

export function useDriverReviews() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getDriverReviews = async (driverId: string): Promise<DriverReview[]> => {
    try {
      const { data, error: fetchError } = await supabase
        .from('driver_reviews')
        .select(`
          *,
          reviewer:reviewer_id(full_name)
        `)
        .eq('driver_id', driverId)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      return data || [];
    } catch (err) {
      console.error('Error fetching driver reviews:', err);
      return [];
    }
  };

  const getDriverStats = async (driverId: string): Promise<ReviewStats | null> => {
    try {
      const { data, error: rpcError } = await supabase
        .rpc('get_driver_review_stats', {
          p_driver_id: driverId
        });

      if (rpcError) throw rpcError;
      return data;
    } catch (err) {
      console.error('Error fetching driver stats:', err);
      return null;
    }
  };

  const createReview = async (reviewData: {
    booking_id: string;
    driver_id: string;
    rating: number;
    comment?: string;
  }) => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: insertError } = await supabase
        .from('driver_reviews')
        .insert([{
          ...reviewData,
          reviewer_id: (await supabase.auth.getUser()).data.user?.id
        }])
        .select()
        .single();

      if (insertError) throw insertError;
      return data;
    } catch (err) {
      setError('Değerlendirme eklenirken bir hata oluştu');
      return null;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    getDriverReviews,
    getDriverStats,
    createReview
  };
}