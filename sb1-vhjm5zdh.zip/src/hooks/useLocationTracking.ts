import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface Location {
  latitude: number;
  longitude: number;
  heading?: number;
  speed?: number;
  updated_at: string;
}

export function useLocationTracking() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateLocation = async (
    driverId: string,
    bookingId: string,
    location: {
      latitude: number;
      longitude: number;
      heading?: number;
      speed?: number;
    }
  ) => {
    try {
      const { error: updateError } = await supabase
        .rpc('update_driver_location', {
          p_driver_id: driverId,
          p_booking_id: bookingId,
          p_latitude: location.latitude,
          p_longitude: location.longitude,
          p_heading: location.heading,
          p_speed: location.speed
        });

      if (updateError) throw updateError;
      return true;
    } catch (err) {
      console.error('Error updating location:', err);
      return false;
    }
  };

  const getLatestLocation = async (
    driverId: string,
    bookingId: string
  ): Promise<Location | null> => {
    try {
      const { data, error } = await supabase
        .rpc('get_latest_driver_location', {
          p_driver_id: driverId,
          p_booking_id: bookingId
        });

      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Error getting latest location:', err);
      return null;
    }
  };

  const subscribeToLocationUpdates = (
    driverId: string,
    bookingId: string,
    onUpdate: (location: Location) => void
  ) => {
    const subscription = supabase
      .channel(`driver-location-${driverId}-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'driver_locations',
          filter: `driver_id=eq.${driverId},booking_id=eq.${bookingId}`
        },
        async (payload) => {
          const location = {
            latitude: payload.new.latitude,
            longitude: payload.new.longitude,
            heading: payload.new.heading,
            speed: payload.new.speed,
            updated_at: payload.new.created_at
          };
          onUpdate(location);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  };

  return {
    loading,
    error,
    updateLocation,
    getLatestLocation,
    subscribeToLocationUpdates
  };
}