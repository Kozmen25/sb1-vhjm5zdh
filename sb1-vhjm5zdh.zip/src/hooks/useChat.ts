import { useEffect, useState } from 'react';
import { useAuthContext } from '../components/AuthProvider';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Chat = Database['public']['Tables']['chats']['Row'] & {
  sender: {
    full_name: string;
  };
  recipient: {
    full_name: string;
  };
};

export function useChat(bookingId: string) {
  const { user } = useAuthContext();
  const [messages, setMessages] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user && bookingId) {
      loadMessages();
      subscribeToNewMessages();
    }
  }, [user, bookingId]);

  const loadMessages = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('chats')
        .select(`
          *,
          sender:sender_id(full_name),
          recipient:recipient_id(full_name)
        `)
        .eq('booking_id', bookingId)
        .order('created_at', { ascending: true });

      if (fetchError) throw fetchError;
      setMessages(data || []);

      // Mark messages as read
      const unreadMessageIds = data
        ?.filter(m => m.recipient_id === user?.id && !m.read)
        .map(m => m.id);

      if (unreadMessageIds?.length) {
        await supabase.rpc('mark_messages_read', {
          p_chat_ids: unreadMessageIds
        });
      }
    } catch (err) {
      console.error('Error loading messages:', err);
      setError('Mesajlar yüklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const subscribeToNewMessages = () => {
    const subscription = supabase
      .channel('chats')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chats',
          filter: `booking_id=eq.${bookingId}`
        },
        async (payload) => {
          const { data: newMessage } = await supabase
            .from('chats')
            .select(`
              *,
              sender:sender_id(full_name),
              recipient:recipient_id(full_name)
            `)
            .eq('id', payload.new.id)
            .single();

          if (newMessage) {
            setMessages(prev => [...prev, newMessage]);

            // Mark message as read if recipient
            if (newMessage.recipient_id === user?.id) {
              await supabase.rpc('mark_messages_read', {
                p_chat_ids: [newMessage.id]
              });
            }
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  };

  const sendMessage = async (recipientId: string, message: string) => {
    if (!user || !message.trim()) return null;

    try {
      const { data, error: sendError } = await supabase
        .from('chats')
        .insert([{
          booking_id: bookingId,
          sender_id: user.id,
          recipient_id: recipientId,
          message: message.trim()
        }])
        .select()
        .single();

      if (sendError) throw sendError;
      return data;
    } catch (err) {
      console.error('Error sending message:', err);
      setError('Mesaj gönderilirken bir hata oluştu');
      return null;
    }
  };

  return {
    messages,
    loading,
    error,
    sendMessage,
    refresh: loadMessages
  };
}