import { useState } from 'react';
import { useAuthContext } from '../components/AuthProvider';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Review = Database['public']['Tables']['reviews']['Row'] & {
  reviewer: {
    full_name: string;
  };
};

export function useReviews() {
  const { user } = useAuthContext();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getReviews = async (userId: string, type?: 'renter_review' | 'owner_review') => {
    try {
      let query = supabase
        .from('reviews')
        .select(`
          *,
          reviewer:reviewer_id(full_name)
        `)
        .eq('reviewee_id', userId)
        .order('created_at', { ascending: false });

      if (type) {
        query = query.eq('type', type);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      return data;
    } catch (err) {
      console.error('Error fetching reviews:', err);
      return [];
    }
  };

  const createReview = async (reviewData: {
    booking_id: string;
    reviewee_id: string;
    vehicle_id: string;
    rating: number;
    comment?: string;
    type: 'renter_review' | 'owner_review';
  }) => {
    if (!user) return null;

    setLoading(true);
    setError(null);

    try {
      const { data, error: insertError } = await supabase
        .from('reviews')
        .insert([{
          ...reviewData,
          reviewer_id: user.id
        }])
        .select()
        .single();

      if (insertError) throw insertError;
      return data;
    } catch (err) {
      setError('Değerlendirme eklenirken bir hata oluştu');
      console.error('Error creating review:', err);
      return null;
    } finally {
      setLoading(false);
    }
  };

  const getUserStats = async (userId: string) => {
    try {
      const [
        { data: averageRating },
        { data: reviewCounts }
      ] = await Promise.all([
        supabase.rpc('calculate_average_rating', { p_user_id: userId }),
        supabase.rpc('get_review_counts', { p_user_id: userId })
      ]);

      return {
        averageRating,
        reviewCounts: reviewCounts as {
          total: number;
          ratings: {
            '1': number;
            '2': number;
            '3': number;
            '4': number;
            '5': number;
          };
        }
      };
    } catch (err) {
      console.error('Error fetching user stats:', err);
      return null;
    }
  };

  return {
    loading,
    error,
    getReviews,
    createReview,
    getUserStats
  };
}