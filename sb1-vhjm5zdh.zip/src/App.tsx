import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './components/AuthProvider';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Header } from './components/Header';
import HomeScreen from './components/screens/HomeScreen';
import LoginScreen from './components/screens/LoginScreen';
import RegisterScreen from './components/screens/RegisterScreen';
import VehicleListScreen from './components/screens/VehicleListScreen';
import VehicleDetailsScreen from './components/screens/VehicleDetailsScreen';
import DriverProfileScreen from './components/screens/DriverProfileScreen';
import BookingScreen from './components/screens/BookingScreen';
import UserProfileScreen from './components/screens/UserProfileScreen';
import UserBookingsScreen from './components/screens/UserBookingsScreen';
import MyVehiclesScreen from './components/screens/MyVehiclesScreen';
import AddVehicleScreen from './components/screens/AddVehicleScreen';
import EditVehicleScreen from './components/screens/EditVehicleScreen';
import RentalRequestsScreen from './components/screens/RentalRequestsScreen';

function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-100">
        <Header />
        <main className="pt-4">
          <Routes>
            <Route path="/" element={<HomeScreen />} />
            <Route path="/login" element={<LoginScreen />} />
            <Route path="/register" element={<RegisterScreen />} />
            <Route path="/vehicles" element={<VehicleListScreen />} />
            <Route path="/vehicles/:id" element={<VehicleDetailsScreen />} />
            <Route 
              path="/drivers/:id" 
              element={
                <ProtectedRoute>
                  <DriverProfileScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/booking" 
              element={
                <ProtectedRoute>
                  <BookingScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/profile" 
              element={
                <ProtectedRoute>
                  <UserProfileScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/bookings" 
              element={
                <ProtectedRoute>
                  <UserBookingsScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/my-vehicles" 
              element={
                <ProtectedRoute>
                  <MyVehiclesScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/add-vehicle" 
              element={
                <ProtectedRoute>
                  <AddVehicleScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/edit-vehicle/:id" 
              element={
                <ProtectedRoute>
                  <EditVehicleScreen />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/rental-requests" 
              element={
                <ProtectedRoute>
                  <RentalRequestsScreen />
                </ProtectedRoute>
              } 
            />
          </Routes>
        </main>
      </div>
    </AuthProvider>
  );
}

export default App