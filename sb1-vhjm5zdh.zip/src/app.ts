import * as React from 'react';
import * as ReactNativeScript from 'react-nativescript';
import { MainStack } from './components/MainStack';
import { Application } from '@nativescript/core';

// Global error handling
Application.on(Application.uncaughtErrorEvent, (args) => {
    if (args.error) {
        console.error('Uncaught error:', args.error.stack || args.error.message || args.error);
    }
});

// Enable development logging
Object.defineProperty(global, '__DEV__', { value: true });

try {
    ReactNativeScript.start(React.createElement(MainStack, {}, null));
} catch (error) {
    console.error('Application start error:', error);
}