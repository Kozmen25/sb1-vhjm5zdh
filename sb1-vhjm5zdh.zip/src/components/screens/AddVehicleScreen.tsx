import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../AuthProvider';
import { supabase } from '../../lib/supabase';
import { ErrorMessage } from '../ErrorMessage';
import { Button } from '../Button';
import { Input } from '../Input';

type VehicleFeature = 'automatic' | 'manual' | 'air_conditioning' | 'navigation' | 'bluetooth' | 'parking_sensors' | 'backup_camera' | 'cruise_control';

const VEHICLE_FEATURES: { value: VehicleFeature; label: string }[] = [
  { value: 'automatic', label: 'Otomatik Vites' },
  { value: 'manual', label: 'Manuel Vites' },
  { value: 'air_conditioning', label: 'Klima' },
  { value: 'navigation', label: 'Navigasyon' },
  { value: 'bluetooth', label: 'Bluetooth' },
  { value: 'parking_sensors', label: 'Park Sensörü' },
  { value: 'backup_camera', label: 'Geri Görüş Kamerası' },
  { value: 'cruise_control', label: 'Hız Sabitleyici' }
];

const VEHICLE_TYPES = [
  'Ekonomik',
  'Kompakt',
  'Orta Sınıf',
  'Üst Sınıf',
  'Premium',
  'SUV',
  'Minivan',
  'Ticari'
];

export default function AddVehicleScreen() {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    type: '',
    price_per_hour: '',
    description: '',
    features: [] as VehicleFeature[]
  });

  const handleFeatureToggle = (feature: VehicleFeature) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter(f => f !== feature)
        : [...prev.features, feature]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    setError(null);

    try {
      const { error: insertError } = await supabase
        .from('vehicles')
        .insert([{
          owner_id: user.id,
          name: formData.name,
          type: formData.type,
          price_per_hour: Number(formData.price_per_hour),
          description: formData.description,
          features: formData.features,
          available: true
        }]);

      if (insertError) throw insertError;

      navigate('/my-vehicles');
    } catch (err) {
      setError('Araç eklenirken bir hata oluştu. Lütfen tekrar deneyin.');
      console.error('Error adding vehicle:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-2xl font-bold mb-6">Yeni Araç Ekle</h1>

          {error && <ErrorMessage message={error} />}

          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Araç Adı"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Örn: 2022 Volkswagen Passat"
              required
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Araç Tipi
              </label>
              <select
                className="w-full p-4 border rounded-lg"
                value={formData.type}
                onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value }))}
                required
              >
                <option value="">Seçiniz</option>
                {VEHICLE_TYPES.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <Input
              label="Saatlik Ücret (₺)"
              type="number"
              value={formData.price_per_hour}
              onChange={(e) => setFormData(prev => ({ ...prev, price_per_hour: e.target.value }))}
              min="1"
              required
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Açıklama
              </label>
              <textarea
                className="w-full p-4 border rounded-lg"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                placeholder="Aracınız hakkında detaylı bilgi verin"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Özellikler
              </label>
              <div className="grid grid-cols-2 gap-4">
                {VEHICLE_FEATURES.map(({ value, label }) => (
                  <label
                    key={value}
                    className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                  >
                    <input
                      type="checkbox"
                      checked={formData.features.includes(value)}
                      onChange={() => handleFeatureToggle(value)}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span>{label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex space-x-4">
              <Button
                type="button"
                variant="secondary"
                className="flex-1"
                onClick={() => navigate('/my-vehicles')}
              >
                İptal
              </Button>
              <Button
                type="submit"
                variant="primary"
                className="flex-1"
                isLoading={loading}
              >
                Araç Ekle
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export { AddVehicleScreen }