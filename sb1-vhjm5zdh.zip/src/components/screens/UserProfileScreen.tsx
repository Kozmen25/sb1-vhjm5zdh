import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../AuthProvider';
import { supabase } from '../../lib/supabase';
import { LoadingSpinner } from '../LoadingSpinner';

function UserProfileScreen() {
  const navigate = useNavigate();
  const { user, signOut } = useAuthContext();
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    phone: ''
  });
  const [updateLoading, setUpdateLoading] = useState(false);

  React.useEffect(() => {
    async function loadUserData() {
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        const { data, error: fetchError } = await supabase
          .from('users')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();

        if (fetchError) throw fetchError;
        
        if (!data) {
          const { data: newUser, error: insertError } = await supabase
            .from('users')
            .insert([{ 
              id: user.id, 
              email: user.email,
              full_name: user.user_metadata?.full_name || 'Kullanıcı'
            }])
            .select()
            .single();

          if (insertError) throw insertError;
          setUserData(newUser);
          setFormData({
            full_name: newUser.full_name || '',
            phone: newUser.phone || ''
          });
        } else {
          setUserData(data);
          setFormData({
            full_name: data.full_name || '',
            phone: data.phone || ''
          });
        }
      } catch (err) {
        console.error('Error loading user data:', err);
        setError('Kullanıcı bilgileri yüklenirken bir hata oluştu. Lütfen tekrar deneyin.');
      } finally {
        setLoading(false);
      }
    }

    loadUserData();
  }, [user]);

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setUpdateLoading(true);
    setError(null);

    try {
      const { error: updateError } = await supabase
        .from('users')
        .update({
          full_name: formData.full_name,
          phone: formData.phone,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      setUserData(prev => ({
        ...prev,
        full_name: formData.full_name,
        phone: formData.phone
      }));
      setIsEditing(false);
    } catch (err) {
      setError('Profil güncellenirken bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setUpdateLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (err) {
      setError('Çıkış yapılırken bir hata oluştu. Lütfen tekrar deneyin.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {error && (
          <div className="bg-red-50 text-red-500 p-4 rounded-lg">
            {error}
          </div>
        )}

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Profilim</h1>
            {!isEditing && (
              <button
                className="text-blue-600 hover:text-blue-700"
                onClick={() => setIsEditing(true)}
              >
                Düzenle
              </button>
            )}
          </div>
          
          {isEditing ? (
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">
                  Ad Soyad
                </label>
                <input
                  type="text"
                  className="w-full p-3 border rounded-lg"
                  value={formData.full_name}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    full_name: e.target.value
                  }))}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">
                  E-posta
                </label>
                <p className="text-lg text-gray-700">{userData?.email || user.email}</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">
                  Telefon
                </label>
                <input
                  type="tel"
                  className="w-full p-3 border rounded-lg"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    phone: e.target.value
                  }))}
                  placeholder="5XX XXX XX XX"
                />
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 text-white bg-blue-600 p-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                  disabled={updateLoading}
                >
                  {updateLoading ? 'Kaydediliyor...' : 'Kaydet'}
                </button>
                <button
                  type="button"
                  className="flex-1 text-blue-600 border border-blue-600 p-3 rounded-lg hover:bg-blue-50 transition-colors"
                  onClick={() => {
                    setIsEditing(false);
                    setFormData({
                      full_name: userData?.full_name || '',
                      phone: userData?.phone || ''
                    });
                  }}
                >
                  İptal
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-600">Ad Soyad</label>
                <p className="text-lg">{userData?.full_name || 'Belirtilmemiş'}</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-600">E-posta</label>
                <p className="text-lg">{userData?.email || user.email}</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-600">Telefon</label>
                <p className="text-lg">{userData?.phone || 'Belirtilmemiş'}</p>
              </div>
            </div>
          )}
        </div>

        <div className="flex space-x-4">
          <button
            className="flex-1 text-lg text-white bg-blue-600 p-4 rounded-lg hover:bg-blue-700 transition-colors"
            onClick={() => navigate('/bookings')}
          >
            Rezervasyonlarım
          </button>
          
          <button
            className="flex-1 text-lg text-red-600 border border-red-600 p-4 rounded-lg hover:bg-red-50 transition-colors"
            onClick={handleSignOut}
          >
            Çıkış Yap
          </button>
        </div>
      </div>
    </div>
  );
}

export default UserProfileScreen;