import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../AuthProvider';
import { supabase } from '../../lib/supabase';
import { LoadingSpinner } from '../LoadingSpinner';
import type { Database } from '../../lib/database.types';

type Vehicle = Database['public']['Tables']['vehicles']['Row'];

export default function MyVehiclesScreen() {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadVehicles();
  }, [user]);

  const loadVehicles = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .eq('owner_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
    } catch (err) {
      setError('Araçlar yüklenirken bir hata oluştu');
      console.error('Error loading vehicles:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleVehicleAvailability = async (vehicleId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('vehicles')
        .update({ available: !currentStatus })
        .eq('id', vehicleId)
        .eq('owner_id', user?.id);

      if (error) throw error;

      setVehicles(vehicles.map(vehicle => 
        vehicle.id === vehicleId 
          ? { ...vehicle, available: !currentStatus }
          : vehicle
      ));
    } catch (err) {
      setError('Araç durumu güncellenirken bir hata oluştu');
      console.error('Error updating vehicle status:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Araçlarım</h1>
          <button
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            onClick={() => navigate('/add-vehicle')}
          >
            Yeni Araç Ekle
          </button>
        </div>

        {error && (
          <div className="bg-red-50 text-red-500 p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        {vehicles.length === 0 ? (
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <p className="text-gray-600 mb-4">Henüz bir araç eklemediniz.</p>
            <button
              className="text-blue-600 hover:text-blue-700 font-medium"
              onClick={() => navigate('/add-vehicle')}
            >
              İlk aracınızı ekleyin
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vehicles.map((vehicle) => (
              <div
                key={vehicle.id}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h2 className="text-xl font-bold">{vehicle.name}</h2>
                      <p className="text-gray-600">{vehicle.type}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      vehicle.available
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {vehicle.available ? 'Müsait' : 'Müsait Değil'}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <p className="text-gray-700">{vehicle.description}</p>
                    <p className="font-semibold">
                      {vehicle.price_per_hour}₺ <span className="text-gray-600">/saat</span>
                    </p>
                  </div>

                  <div className="flex space-x-2">
                    <button
                      className="flex-1 text-blue-600 border border-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors"
                      onClick={() => navigate(`/edit-vehicle/${vehicle.id}`)}
                    >
                      Düzenle
                    </button>
                    <button
                      className={`flex-1 px-4 py-2 rounded-lg transition-colors ${
                        vehicle.available
                          ? 'text-red-600 border border-red-600 hover:bg-red-50'
                          : 'text-green-600 border border-green-600 hover:bg-green-50'
                      }`}
                      onClick={() => toggleVehicleAvailability(vehicle.id, vehicle.available)}
                    >
                      {vehicle.available ? 'Devre Dışı Bırak' : 'Aktif Et'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export { MyVehiclesScreen }