import React from 'react';
import { useParams } from 'react-router-dom';

export default function DriverProfileScreen() {
  const { id } = useParams();

  // Örnek veri - API çağrısı ile değiştirilecek
  const driver = {
    id: id,
    name: "Ahmet Yılmaz",
    rating: 4.8,
    trips: 156,
    joinedDate: "Ocak 2022",
    languages: ["Türkçe", "İngilizce"],
    bio: "5 yılı aşkın deneyime sahip profesyonel sürücü. Güvenli ve konforlu yolculuklar sağlamayı taahhüt ediyorum.",
    reviews: [
      {
        id: 1,
        user: "Ayşe",
        rating: 5,
        comment: "Mükemmel hizmet! Çok profesyonel ve dakik."
      },
      {
        id: 2,
        user: "Mehmet",
        rating: 4,
        comment: "Harika sürücü, şehir hakkında çok bilgili."
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h1 className="text-2xl font-bold">{driver.name}</h1>
          <p className="text-lg text-gray-600">⭐ {driver.rating}</p>
          <p className="text-gray-600">{driver.trips} sefer</p>
          <p className="text-gray-600">Üyelik: {driver.joinedDate}</p>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-2">Hakkında</h2>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-700">{driver.bio}</p>
            <p className="text-gray-700 mt-2">Diller: {driver.languages.join(", ")}</p>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-2">Değerlendirmeler</h2>
          {driver.reviews.map((review) => (
            <div 
              key={review.id}
              className="bg-white p-4 rounded-lg shadow-md mb-4"
            >
              <div className="flex justify-between">
                <p className="font-semibold">{review.user}</p>
                <p>{"⭐".repeat(review.rating)}</p>
              </div>
              <p className="text-gray-700 mt-1">{review.comment}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export { DriverProfileScreen }