import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useVehicles } from '../../hooks/useVehicles';
import { useDrivers } from '../../hooks/useDrivers';
import { LoadingSpinner } from '../LoadingSpinner';
import type { Database } from '../../lib/database.types';

type Vehicle = Database['public']['Tables']['vehicles']['Row'];
type Driver = Database['public']['Tables']['drivers']['Row'] & {
  users: { full_name: string; email: string; }
};

export default function VehicleDetailsScreen() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { getVehicleById } = useVehicles();
  const { getDriverById } = useDrivers();
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [driver, setDriver] = useState<Driver | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState(0);

  useEffect(() => {
    async function loadData() {
      try {
        if (!id) throw new Error("Vehicle ID is required");
        
        const vehicleData = await getVehicleById(id);
        if (!vehicleData) throw new Error("Vehicle not found");
        
        setVehicle(vehicleData);
        
        const driverData = await getDriverById("d1");
        if (driverData) setDriver(driverData);
        
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 p-6 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !vehicle) {
    return (
      <div className="min-h-screen bg-gray-100 p-6 flex items-center justify-center">
        <p className="text-lg text-red-600">Hata: {error || 'Araç bulunamadı'}</p>
      </div>
    );
  }

  // Example images array - in production, these would come from the vehicle data
  const images = [
    'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800',
    'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800',
    'https://images.unsplash.com/photo-1542282088-fe8426682b8f?w=800'
  ];

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="relative">
            <img
              src={images[selectedImage]}
              alt={vehicle.name}
              className="w-full h-96 object-cover"
            />
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
              {images.map((_, index) => (
                <button
                  key={index}
                  className={`w-3 h-3 rounded-full ${
                    selectedImage === index ? 'bg-white' : 'bg-white/50'
                  }`}
                  onClick={() => setSelectedImage(index)}
                />
              ))}
            </div>
          </div>

          <div className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-bold">{vehicle.name}</h1>
                <p className="text-lg text-gray-600 mt-1">{vehicle.type}</p>
              </div>
              <p className="text-2xl font-bold text-blue-600">
                {vehicle.price_per_hour}₺
                <span className="text-sm text-gray-600">/saat</span>
              </p>
            </div>

            <p className="text-gray-700 mt-4">{vehicle.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">Özellikler</h2>
            <div className="grid grid-cols-2 gap-4">
              {vehicle.features && Array.isArray(vehicle.features) && vehicle.features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {driver && (
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">Sürücü</h2>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                    <span className="text-2xl text-gray-600">
                      {driver.users.full_name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-semibold">{driver.users.full_name}</p>
                    <div className="flex items-center space-x-2">
                      <span className="text-yellow-500">⭐</span>
                      <span className="font-medium">{driver.rating}</span>
                      <span className="text-gray-600">•</span>
                      <span className="text-gray-600">{driver.trips_count} sefer</span>
                    </div>
                  </div>
                </div>
                
                {driver.languages && (
                  <div>
                    <p className="font-medium text-gray-700">Konuştuğu Diller</p>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {driver.languages.map((lang, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-gray-100 rounded-full text-sm text-gray-700"
                        >
                          {lang}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {driver.bio && (
                  <p className="text-gray-700">{driver.bio}</p>
                )}

                <button
                  className="text-blue-600 hover:text-blue-700 font-medium"
                  onClick={() => navigate(`/drivers/${driver.id}`)}
                >
                  Sürücü Profilini Gör
                </button>
              </div>
            </div>
          )}
        </div>

        <button
          className="w-full text-lg text-white bg-blue-600 p-4 rounded-lg hover:bg-blue-700 transition-colors"
          onClick={() => navigate('/booking', { 
            state: { vehicleId: vehicle.id, driverId: driver?.id }
          })}
        >
          Hemen Kirala
        </button>
      </div>
    </div>
  );
}

export { VehicleDetailsScreen }