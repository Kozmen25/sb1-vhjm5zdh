import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVehicles } from '../../hooks/useVehicles';
import { LoadingSpinner } from '../LoadingSpinner';

export default function VehicleListScreen() {
  const navigate = useNavigate();
  const { vehicles, loading, error } = useVehicles();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });

  // Get unique vehicle types
  const vehicleTypes = [...new Set(vehicles.map(vehicle => vehicle.type))];

  // Filter vehicles based on search, type, and price range
  const filteredVehicles = vehicles.filter(vehicle => {
    const matchesSearch = vehicle.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vehicle.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = !selectedType || vehicle.type === selectedType;
    const matchesPrice = (!priceRange.min || vehicle.price_per_hour >= Number(priceRange.min)) &&
                        (!priceRange.max || vehicle.price_per_hour <= Number(priceRange.max));
    
    return matchesSearch && matchesType && matchesPrice;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 p-6 flex items-center justify-center">
        <p className="text-lg text-red-600">Hata: {error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h1 className="text-2xl font-bold mb-6">Araç Arama</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Araç Ara
              </label>
              <input
                type="text"
                className="w-full p-3 border rounded-lg"
                placeholder="Araç adı veya açıklama..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Vehicle type filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Araç Tipi
              </label>
              <select
                className="w-full p-3 border rounded-lg bg-white"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
              >
                <option value="">Tümü</option>
                {vehicleTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Price range filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Saatlik Fiyat Aralığı (₺)
              </label>
              <div className="flex space-x-2">
                <input
                  type="number"
                  className="w-1/2 p-3 border rounded-lg"
                  placeholder="Min"
                  value={priceRange.min}
                  onChange={(e) => setPriceRange(prev => ({ ...prev, min: e.target.value }))}
                />
                <input
                  type="number"
                  className="w-1/2 p-3 border rounded-lg"
                  placeholder="Max"
                  value={priceRange.max}
                  onChange={(e) => setPriceRange(prev => ({ ...prev, max: e.target.value }))}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Results count */}
        <p className="text-gray-600 mb-4">
          {filteredVehicles.length} araç bulundu
        </p>

        {/* Vehicle grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVehicles.map((vehicle) => (
            <div
              key={vehicle.id}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-6">
                <h2 className="text-xl font-bold mb-2">{vehicle.name}</h2>
                <p className="text-gray-600 mb-2">{vehicle.type}</p>
                {vehicle.description && (
                  <p className="text-gray-600 mb-4 line-clamp-2">{vehicle.description}</p>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-blue-600">
                    {vehicle.price_per_hour}₺
                    <span className="text-sm text-gray-600">/saat</span>
                  </span>
                  <button
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    onClick={() => navigate(`/vehicles/${vehicle.id}`)}
                  >
                    İncele
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredVehicles.length === 0 && (
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <p className="text-gray-600">
              Arama kriterlerinize uygun araç bulunamadı.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export { VehicleListScreen }