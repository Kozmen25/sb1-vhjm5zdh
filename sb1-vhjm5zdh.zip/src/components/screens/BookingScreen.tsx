import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthContext } from '../AuthProvider';
import { useBookings } from '../../hooks/useBookings';
import { useVehicles } from '../../hooks/useVehicles';

export default function BookingScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const { vehicleId, driverId } = location.state || {};
  const { user } = useAuthContext();
  const { createBooking } = useBookings();
  const { getVehicleById } = useVehicles();
  
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [hours, setHours] = useState("2");
  const [pickupLocation, setPickupLocation] = useState("");
  const [dropoffLocation, setDropoffLocation] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [vehicle, setVehicle] = React.useState(null);

  React.useEffect(() => {
    async function loadVehicle() {
      if (vehicleId) {
        const data = await getVehicleById(vehicleId);
        setVehicle(data);
      }
    }
    loadVehicle();
  }, [vehicleId]);

  if (!vehicle) {
    return <div>Loading...</div>;
  }

  const totalPrice = Number(hours) * vehicle.price_per_hour;

  const handleBooking = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    setLoading(true);
    setError("");

    try {
      const booking = await createBooking({
        user_id: user.id,
        vehicle_id: vehicleId,
        driver_id: driverId,
        start_time: new Date(date).toISOString(),
        duration_hours: Number(hours),
        pickup_location: pickupLocation,
        dropoff_location: dropoffLocation,
        status: 'pending',
        total_amount: totalPrice
      });

      if (booking) {
        alert("Rezervasyon başarıyla oluşturuldu!");
        navigate('/');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-2xl font-bold">{vehicle.name} Kirala</h1>

        {error && (
          <div className="bg-red-50 text-red-500 p-4 rounded-lg">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-lg font-semibold mb-2">Alış Tarihi</label>
            <input
              type="date"
              className="w-full p-4 border rounded-lg"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-lg font-semibold mb-2">Süre (saat)</label>
            <input
              type="number"
              className="w-full p-4 border rounded-lg"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              min="1"
            />
          </div>

          <div>
            <label className="block text-lg font-semibold mb-2">Alış Noktası</label>
            <input
              type="text"
              className="w-full p-4 border rounded-lg"
              placeholder="Alış adresini girin"
              value={pickupLocation}
              onChange={(e) => setPickupLocation(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-lg font-semibold mb-2">Teslim Noktası</label>
            <input
              type="text"
              className="w-full p-4 border rounded-lg"
              placeholder="Teslim adresini girin"
              value={dropoffLocation}
              onChange={(e) => setDropoffLocation(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold">Fiyat Özeti</h2>
          <div className="mt-2 space-y-2">
            <div className="flex justify-between">
              <span>Saatlik Ücret</span>
              <span>{vehicle.price_per_hour}₺</span>
            </div>
            <div className="flex justify-between">
              <span>Saat</span>
              <span>{hours}</span>
            </div>
            <div className="flex justify-between pt-2 border-t font-bold">
              <span>Toplam</span>
              <span>{totalPrice}₺</span>
            </div>
          </div>
        </div>

        <button
          className="w-full text-lg text-white bg-blue-600 p-4 rounded-lg disabled:opacity-50"
          onClick={handleBooking}
          disabled={loading}
        >
          {loading ? 'İşleniyor...' : 'Rezervasyonu Onayla'}
        </button>
      </div>
    </div>
  );
}

export { BookingScreen }