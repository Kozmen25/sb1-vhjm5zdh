import React, { useState, useEffect } from 'react';
import { useAuthContext } from '../AuthProvider';
import { supabase } from '../../lib/supabase';
import { LoadingSpinner } from '../LoadingSpinner';
import { ErrorMessage } from '../ErrorMessage';
import type { Database } from '../../lib/database.types';

type RentalRequest = Database['public']['Tables']['rental_requests']['Row'] & {
  vehicles: Database['public']['Tables']['vehicles']['Row'];
  users: {
    full_name: string;
    email: string;
  };
};

export default function RentalRequestsScreen() {
  const { user } = useAuthContext();
  const [requests, setRequests] = useState<RentalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');

  useEffect(() => {
    loadRequests();
  }, [user, selectedStatus]);

  const loadRequests = async () => {
    if (!user) return;

    try {
      let query = supabase
        .from('rental_requests')
        .select(`
          *,
          vehicles (*),
          users (full_name, email)
        `)
        .order('created_at', { ascending: false });

      if (selectedStatus !== 'all') {
        query = query.eq('status', selectedStatus);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setRequests(data || []);
    } catch (err) {
      setError('Kiralama talepleri yüklenirken bir hata oluştu');
      console.error('Error loading rental requests:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (requestId: string, newStatus: 'accepted' | 'rejected') => {
    try {
      const { error: updateError } = await supabase
        .from('rental_requests')
        .update({
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', requestId);

      if (updateError) throw updateError;

      setRequests(prev =>
        prev.map(request =>
          request.id === requestId
            ? { ...request, status: newStatus }
            : request
        )
      );
    } catch (err) {
      setError('Talep durumu güncellenirken bir hata oluştu');
      console.error('Error updating request status:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Kiralama Talepleri</h1>
          <div className="flex space-x-2">
            <select
              className="p-2 border rounded-lg"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value as any)}
            >
              <option value="all">Tümü</option>
              <option value="pending">Bekleyen</option>
              <option value="accepted">Kabul Edilen</option>
              <option value="rejected">Reddedilen</option>
            </select>
          </div>
        </div>

        {error && <ErrorMessage message={error} />}

        {requests.length === 0 ? (
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <p className="text-gray-600">
              {selectedStatus === 'all'
                ? 'Henüz kiralama talebi bulunmuyor.'
                : `${selectedStatus === 'pending' ? 'Bekleyen' : selectedStatus === 'accepted' ? 'Kabul edilen' : 'Reddedilen'} kiralama talebi bulunmuyor.`}
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {requests.map((request) => (
              <div
                key={request.id}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h2 className="text-xl font-bold">{request.vehicles.name}</h2>
                      <p className="text-gray-600">Talep Eden: {request.users.full_name}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      request.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : request.status === 'accepted'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {request.status === 'pending'
                        ? 'Beklemede'
                        : request.status === 'accepted'
                        ? 'Kabul Edildi'
                        : 'Reddedildi'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Başlangıç Tarihi</p>
                      <p>{new Date(request.start_time).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Süre</p>
                      <p>{request.duration_hours} saat</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Alış Noktası</p>
                      <p>{request.pickup_location}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Teslim Noktası</p>
                      <p>{request.dropoff_location}</p>
                    </div>
                  </div>

                  {request.message && (
                    <div className="mb-4">
                      <p className="text-sm text-gray-600">Mesaj</p>
                      <p className="mt-1">{request.message}</p>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-4 border-t">
                    <p className="font-bold text-lg">
                      Toplam: {request.total_amount}₺
                    </p>
                    {request.status === 'pending' && (
                      <div className="flex space-x-2">
                        <button
                          className="px-4 py-2 text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors"
                          onClick={() => handleStatusUpdate(request.id, 'accepted')}
                        >
                          Kabul Et
                        </button>
                        <button
                          className="px-4 py-2 text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors"
                          onClick={() => handleStatusUpdate(request.id, 'rejected')}
                        >
                          Reddet
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export { RentalRequestsScreen }