import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../AuthProvider';

export default function HomeScreen() {
  const navigate = useNavigate();
  const { user } = useAuthContext();

  // Get user type from metadata
  const userType = user?.user_metadata?.user_type;

  const renderUserTypeSpecificContent = () => {
    switch (userType) {
      case 'vehicle_owner':
        return (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Araçlarım</h2>
              <p className="text-gray-600 mb-4">
                Araçlarınızı yönetin ve kiralama durumlarını takip edin
              </p>
              <button
                className="w-full text-white bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                onClick={() => navigate('/my-vehicles')}
              >
                Araçlarımı Yönet
              </button>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Rezervasyonlar</h2>
              <p className="text-gray-600 mb-4">
                Gelen kiralama taleplerini görüntüleyin ve yönetin
              </p>
              <button
                className="w-full text-white bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                onClick={() => navigate('/rental-requests')}
              >
                Talepleri Görüntüle
              </button>
            </div>
          </div>
        );

      case 'renter_with_driver':
        return (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Şoförlü Araçlar</h2>
              <p className="text-gray-600 mb-4">
                Profesyonel sürücülerle birlikte kiralayabileceğiniz araçları keşfedin
              </p>
              <button
                className="w-full text-white bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                onClick={() => navigate('/vehicles?with_driver=true')}
              >
                Araçları İncele
              </button>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Seyahatlerim</h2>
              <p className="text-gray-600 mb-4">
                Geçmiş ve gelecek seyahatlerinizi görüntüleyin
              </p>
              <button
                className="w-full text-white bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                onClick={() => navigate('/my-trips')}
              >
                Seyahatleri Görüntüle
              </button>
            </div>
          </div>
        );

      case 'renter':
        return (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Araç Kirala</h2>
              <p className="text-gray-600 mb-4">
                İhtiyacınıza uygun aracı seçin ve hemen kiralayın
              </p>
              <button
                className="w-full text-white bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                onClick={() => navigate('/vehicles')}
              >
                Araçları İncele
              </button>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Kiralamalarım</h2>
              <p className="text-gray-600 mb-4">
                Aktif ve geçmiş kiralamalarınızı görüntüleyin
              </p>
              <button
                className="w-full text-white bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                onClick={() => navigate('/bookings')}
              >
                Kiralamaları Görüntüle
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          DriveMate ile Araç Kiralama Kolaylaşır
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          {user ? 'Hemen başlayın ve ihtiyacınıza uygun aracı seçin' : 'İstediğiniz aracı, istediğiniz zaman kiralayın'}
        </p>
        
        {user ? (
          renderUserTypeSpecificContent()
        ) : (
          <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-md mx-auto">
            <button
              className="w-full sm:w-auto text-lg text-white bg-blue-600 px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors"
              onClick={() => navigate('/login')}
            >
              Giriş Yap
            </button>
            
            <button
              className="w-full sm:w-auto text-lg text-blue-600 border-2 border-blue-600 px-8 py-4 rounded-lg hover:bg-blue-50 transition-colors"
              onClick={() => navigate('/register')}
            >
              Kayıt Ol
            </button>
          </div>
        )}

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Geniş Araç Filosu</h2>
            <p className="text-gray-600">
              Ekonomik araçlardan lüks araçlara kadar geniş bir yelpazede seçim yapın
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Profesyonel Sürücüler</h2>
            <p className="text-gray-600">
              Deneyimli ve güvenilir sürücülerle güvenli yolculuklar
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Kolay Rezervasyon</h2>
            <p className="text-gray-600">
              Birkaç tıkla istediğiniz aracı rezerve edin
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export { HomeScreen }