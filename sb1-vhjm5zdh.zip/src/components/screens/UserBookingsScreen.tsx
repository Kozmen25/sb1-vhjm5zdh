import React from 'react';
import { useBookings } from '../../hooks/useBookings';
import { useAuthContext } from '../AuthProvider';
import { LoadingSpinner } from '../LoadingSpinner';

export default function UserBookingsScreen() {
  const { user } = useAuthContext();
  const { getUserBookings } = useBookings();
  const [bookings, setBookings] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    async function loadBookings() {
      if (!user) return;
      try {
        const data = await getUserBookings(user.id);
        setBookings(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    loadBookings();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-red-50 text-red-500 p-4 rounded-lg">
            {error}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Rezervasyonlarım</h1>
        
        {bookings.length === 0 ? (
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <p className="text-gray-600">Henüz bir rezervasyonunuz bulunmuyor.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <div key={booking.id} className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-xl font-semibold">{booking.vehicles.name}</h2>
                    <p className="text-gray-600">{booking.drivers.users.full_name}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    booking.status === 'completed' ? 'bg-green-100 text-green-800' :
                    booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {booking.status === 'completed' ? 'Tamamlandı' :
                     booking.status === 'pending' ? 'Beklemede' :
                     booking.status}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Başlangıç</p>
                    <p>{new Date(booking.start_time).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Süre</p>
                    <p>{booking.duration_hours} saat</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Alış Noktası</p>
                    <p>{booking.pickup_location}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Teslim Noktası</p>
                    <p>{booking.dropoff_location}</p>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t">
                  <div className="flex justify-between items-center">
                    <p className="font-semibold">Toplam Tutar</p>
                    <p className="text-lg font-bold">{booking.total_amount}₺</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}