import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

type UserType = 'renter' | 'renter_with_driver' | 'vehicle_owner' | null;

export default function RegisterScreen() {
  const navigate = useNavigate();
  const { signUp } = useAuth();
  const [step, setStep] = useState<1 | 2>(1);
  const [userType, setUserType] = useState<UserType>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleUserTypeSelection = (type: UserType) => {
    setUserType(type);
    setStep(2);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!userType) {
      setError("Lütfen bir kullanıcı tipi seçin");
      return;
    }

    if (password !== confirmPassword) {
      setError("Şifreler eşleşmiyor");
      return;
    }

    setLoading(true);

    try {
      const { error } = await signUp(email, password, name, userType);
      if (error) throw error;
      navigate('/login');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 py-12 px-4">
      <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-2xl mb-8 font-bold text-center">
          {step === 1 ? 'Nasıl Kullanmak İstersiniz?' : 'Hesap Oluştur'}
        </h1>
        
        {step === 1 ? (
          <div className="space-y-4">
            <button
              className="w-full p-6 text-left border rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
              onClick={() => handleUserTypeSelection('renter')}
            >
              <h2 className="text-lg font-semibold mb-2">Araç Kiralamak İstiyorum</h2>
              <p className="text-gray-600">Araç kiralayarak yolculuk yapmak istiyorum</p>
            </button>

            <button
              className="w-full p-6 text-left border rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
              onClick={() => handleUserTypeSelection('renter_with_driver')}
            >
              <h2 className="text-lg font-semibold mb-2">Şoförlü Araç Kiralamak İstiyorum</h2>
              <p className="text-gray-600">Şoförü ile birlikte araç kiralamak istiyorum</p>
            </button>

            <button
              className="w-full p-6 text-left border rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
              onClick={() => handleUserTypeSelection('vehicle_owner')}
            >
              <h2 className="text-lg font-semibold mb-2">Aracımı Kiralamak İstiyorum</h2>
              <p className="text-gray-600">Kendi aracımı kiralayarak ek gelir elde etmek istiyorum</p>
            </button>

            <button
              type="button"
              className="w-full text-lg text-blue-600 p-4 rounded-lg mt-4"
              onClick={() => navigate('/login')}
            >
              Zaten hesabınız var mı? Giriş Yapın
            </button>
          </div>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            {error && (
              <div className="bg-red-50 text-red-500 p-4 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ad Soyad
              </label>
              <input
                className="w-full p-4 border rounded-lg"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                E-posta
              </label>
              <input
                className="w-full p-4 border rounded-lg"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Şifre
              </label>
              <input
                className="w-full p-4 border rounded-lg"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Şifre Tekrar
              </label>
              <input
                className="w-full p-4 border rounded-lg"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>

            <div className="flex space-x-4">
              <button
                type="button"
                className="flex-1 text-lg text-blue-600 border border-blue-600 p-4 rounded-lg"
                onClick={() => setStep(1)}
              >
                Geri
              </button>

              <button
                type="submit"
                className="flex-1 text-lg text-white bg-blue-600 p-4 rounded-lg disabled:opacity-50"
                disabled={loading}
              >
                {loading ? 'Kayıt yapılıyor...' : 'Kayıt Ol'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export { RegisterScreen }