import React, { useState } from 'react';
import { useReviews } from '../hooks/useReviews';
import { Button } from './Button';
import { ErrorMessage } from './ErrorMessage';

interface ReviewFormProps {
  bookingId: string;
  revieweeId: string;
  vehicleId: string;
  type: 'renter_review' | 'owner_review';
  onSuccess?: () => void;
  onCancel?: () => void;
}

export function ReviewForm({
  bookingId,
  revieweeId,
  vehicleId,
  type,
  onSuccess,
  onCancel
}: ReviewFormProps) {
  const { createReview, loading, error } = useReviews();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const review = await createReview({
      booking_id: bookingId,
      reviewee_id: revieweeId,
      vehicle_id: vehicleId,
      rating,
      comment: comment.trim(),
      type
    });

    if (review) {
      onSuccess?.();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && <ErrorMessage message={error} />}

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Değerlendirme
        </label>
        <div className="flex space-x-2">
          {[1, 2, 3, 4, 5].map((value) => (
            <button
              key={value}
              type="button"
              className="text-2xl focus:outline-none"
              onClick={() => setRating(value)}
            >
              <span className={value <= rating ? 'text-yellow-400' : 'text-gray-300'}>
                ★
              </span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Yorum
        </label>
        <textarea
          className="w-full p-3 border rounded-lg"
          rows={4}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Deneyiminizi paylaşın..."
        />
      </div>

      <div className="flex space-x-4">
        {onCancel && (
          <Button
            type="button"
            variant="secondary"
            className="flex-1"
            onClick={onCancel}
          >
            İptal
          </Button>
        )}
        <Button
          type="submit"
          variant="primary"
          className="flex-1"
          isLoading={loading}
        >
          Değerlendir
        </Button>
      </div>
    </form>
  );
}