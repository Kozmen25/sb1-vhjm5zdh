import React from 'react';
import { useReviews } from '../hooks/useReviews';
import { LoadingSpinner } from './LoadingSpinner';

interface ReviewStatsProps {
  userId: string;
}

export function ReviewStats({ userId }: ReviewStatsProps) {
  const { getUserStats } = useReviews();
  const [stats, setStats] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    loadStats();
  }, [userId]);

  const loadStats = async () => {
    const data = await getUserStats(userId);
    setStats(data);
    setLoading(false);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!stats) {
    return null;
  }

  const { averageRating, reviewCounts } = stats;
  const totalReviews = reviewCounts.total;

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <div className="flex items-center space-x-4">
        <div className="text-center">
          <div className="text-3xl font-bold text-gray-900">
            {averageRating.toFixed(1)}
          </div>
          <div className="flex text-yellow-400 justify-center">
            {Array.from({ length: 5 }).map((_, i) => (
              <span
                key={i}
                className={i < Math.round(averageRating) ? 'text-yellow-400' : 'text-gray-300'}
              >
                ★
              </span>
            ))}
          </div>
          <div className="text-sm text-gray-500">
            {totalReviews} değerlendirme
          </div>
        </div>

        <div className="flex-1">
          {[5, 4, 3, 2, 1].map((rating) => {
            const count = reviewCounts.ratings[rating as keyof typeof reviewCounts.ratings];
            const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;

            return (
              <div key={rating} className="flex items-center space-x-2">
                <div className="text-sm text-gray-600 w-6">{rating}</div>
                <div className="flex-1 h-2 bg-gray-200 rounded">
                  <div
                    className="h-full bg-yellow-400 rounded"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <div className="text-sm text-gray-600 w-10">
                  {count}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}