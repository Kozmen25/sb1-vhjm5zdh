import React from 'react';
import { usePayments } from '../hooks/usePayments';
import { LoadingSpinner } from './LoadingSpinner';

interface PaymentStatusProps {
  bookingId: string;
}

export function PaymentStatus({ bookingId }: PaymentStatusProps) {
  const { getPaymentsByBookingId } = usePayments();
  const [payments, setPayments] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    loadPayments();
  }, [bookingId]);

  const loadPayments = async () => {
    const data = await getPaymentsByBookingId(bookingId);
    setPayments(data);
    setLoading(false);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (payments.length === 0) {
    return null;
  }

  const lastPayment = payments[0];

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-2">Ödeme Durumu</h3>
      
      <div className="flex items-center space-x-2">
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            lastPayment.status === 'succeeded'
              ? 'bg-green-100 text-green-800'
              : lastPayment.status === 'failed'
              ? 'bg-red-100 text-red-800'
              : 'bg-yellow-100 text-yellow-800'
          }`}
        >
          {lastPayment.status === 'succeeded'
            ? 'Ödeme Tamamlandı'
            : lastPayment.status === 'failed'
            ? 'Ödeme Başarısız'
            : 'Ödeme Bekliyor'}
        </span>
      </div>

      <div className="mt-2">
        <p className="text-sm text-gray-600">
          Tutar: <span className="font-medium">{lastPayment.amount}₺</span>
        </p>
        <p className="text-sm text-gray-600">
          Tarih: {new Date(lastPayment.created_at).toLocaleString()}
        </p>
      </div>
    </div>
  );
}