import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuthContext } from './AuthProvider';

export function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthContext();

  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold text-blue-600">
              DriveMate
            </Link>
          </div>

          <nav className="flex items-center space-x-4">
            <Link
              to="/vehicles"
              className={`text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md ${
                location.pathname === '/vehicles' ? 'bg-blue-50' : ''
              }`}
            >
              Araçlar
            </Link>

            {user ? (
              <>
                <Link
                  to="/bookings"
                  className={`text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md ${
                    location.pathname === '/bookings' ? 'bg-blue-50' : ''
                  }`}
                >
                  Rezervasyonlarım
                </Link>
                <div className="relative group">
                  <button
                    className="flex items-center space-x-1 text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md"
                    onClick={() => navigate('/profile')}
                  >
                    <span>Profilim</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => navigate('/login')}
                  className="text-blue-600 hover:text-blue-700 px-4 py-2 rounded-md"
                >
                  Giriş Yap
                </button>
                <button
                  onClick={() => navigate('/register')}
                  className="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-md"
                >
                  Kayıt Ol
                </button>
              </div>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}