import React, { useState } from 'react';
import { CardElement, useStripe, useElements } from '@stripe/stripe-js';
import { usePayments } from '../hooks/usePayments';
import { Button } from './Button';
import { ErrorMessage } from './ErrorMessage';

interface PaymentFormProps {
  bookingId: string;
  amount: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export function PaymentForm({
  bookingId,
  amount,
  onSuccess,
  onCancel
}: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { createPayment, confirmPayment, loading, error } = usePayments();
  const [cardError, setCardError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setCardError(null);

    // Create payment
    const result = await createPayment(bookingId, amount);
    if (!result) return;

    const { paymentId, clientSecret } = result;

    // Confirm payment
    const success = await confirmPayment(clientSecret, paymentId);
    if (success) {
      onSuccess?.();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {(error || cardError) && (
        <ErrorMessage message={error || cardError} />
      )}

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">Ödeme Bilgileri</h3>
        
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">Ödenecek Tutar</p>
          <p className="text-2xl font-bold">{amount}₺</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Kart Bilgileri
            </label>
            <div className="p-4 border rounded-lg">
              <CardElement
                options={{
                  style: {
                    base: {
                      fontSize: '16px',
                      color: '#424770',
                      '::placeholder': {
                        color: '#aab7c4',
                      },
                    },
                    invalid: {
                      color: '#9e2146',
                    },
                  },
                }}
                onChange={(e) => {
                  if (e.error) {
                    setCardError(e.error.message);
                  } else {
                    setCardError(null);
                  }
                }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex space-x-4">
        {onCancel && (
          <Button
            type="button"
            variant="secondary"
            className="flex-1"
            onClick={onCancel}
          >
            İptal
          </Button>
        )}
        <Button
          type="submit"
          variant="primary"
          className="flex-1"
          isLoading={loading}
          disabled={!stripe || !elements || loading}
        >
          Ödemeyi Tamamla
        </Button>
      </div>
    </form>
  );
}