import React from 'react';
import { Link } from 'react-router-dom';

interface VehicleCardProps {
  vehicle: {
    id: string;
    name: string;
    type: string;
    price_per_hour: number;
    description?: string;
    features?: string[];
    available: boolean;
  };
}

export function VehicleCard({ vehicle }: VehicleCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <img
          src="https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800"
          alt={vehicle.name}
          className="w-full h-48 object-cover"
        />
        {!vehicle.available && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <span className="text-white text-lg font-semibold">Müsait Değil</span>
          </div>
        )}
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h2 className="text-xl font-bold">{vehicle.name}</h2>
            <p className="text-gray-600">{vehicle.type}</p>
          </div>
          <span className="text-2xl font-bold text-blue-600">
            {vehicle.price_per_hour}₺
            <span className="text-sm text-gray-600">/saat</span>
          </span>
        </div>

        {vehicle.description && (
          <p className="text-gray-700 mb-4 line-clamp-2">{vehicle.description}</p>
        )}

        {vehicle.features && vehicle.features.length > 0 && (
          <div className="mb-4">
            <div className="flex flex-wrap gap-2">
              {vehicle.features.slice(0, 3).map((feature, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                >
                  {feature}
                </span>
              ))}
              {vehicle.features.length > 3 && (
                <span className="px-2 py-1 text-gray-500 text-sm">
                  +{vehicle.features.length - 3} daha
                </span>
              )}
            </div>
          </div>
        )}

        <Link
          to={`/vehicles/${vehicle.id}`}
          className="block w-full text-center text-white bg-blue-600 px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          İncele
        </Link>
      </div>
    </div>
  );
}