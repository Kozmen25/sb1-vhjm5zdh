import React, { useEffect, useRef } from 'react';
import { Loader } from '@googlemaps/js-api-loader';

interface LocationMapProps {
  location: {
    latitude: number;
    longitude: number;
    heading?: number;
  };
  destination?: {
    latitude: number;
    longitude: number;
  };
}

export function LocationMap({ location, destination }: LocationMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);
  const destinationMarkerRef = useRef<google.maps.Marker | null>(null);
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);

  useEffect(() => {
    const loader = new Loader({
      apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
      version: 'weekly'
    });

    loader.load().then(() => {
      const { Map, Marker } = google.maps;

      if (!mapInstanceRef.current) {
        mapInstanceRef.current = new Map(mapRef.current!, {
          center: { lat: location.latitude, lng: location.longitude },
          zoom: 15,
          styles: [
            {
              featureType: 'poi',
              elementType: 'labels',
              stylers: [{ visibility: 'off' }]
            }
          ]
        });

        // Create driver marker
        markerRef.current = new Marker({
          map: mapInstanceRef.current,
          position: { lat: location.latitude, lng: location.longitude },
          icon: {
            path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
            scale: 6,
            fillColor: '#2563eb',
            fillOpacity: 1,
            strokeWeight: 2,
            strokeColor: '#ffffff',
            rotation: location.heading || 0
          }
        });

        // Create destination marker if destination exists
        if (destination) {
          destinationMarkerRef.current = new Marker({
            map: mapInstanceRef.current,
            position: { 
              lat: destination.latitude, 
              lng: destination.longitude 
            },
            icon: {
              url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
            }
          });

          // Create directions renderer
          directionsRendererRef.current = new google.maps.DirectionsRenderer({
            map: mapInstanceRef.current,
            suppressMarkers: true,
            polylineOptions: {
              strokeColor: '#2563eb',
              strokeWeight: 4
            }
          });

          // Calculate and display route
          calculateRoute();
        }
      }
    });

    return () => {
      if (markerRef.current) {
        markerRef.current.setMap(null);
      }
      if (destinationMarkerRef.current) {
        destinationMarkerRef.current.setMap(null);
      }
      if (directionsRendererRef.current) {
        directionsRendererRef.current.setMap(null);
      }
    };
  }, []);

  useEffect(() => {
    if (markerRef.current && mapInstanceRef.current) {
      const newPosition = { 
        lat: location.latitude, 
        lng: location.longitude 
      };

      // Update marker position and rotation
      markerRef.current.setPosition(newPosition);
      if (location.heading !== undefined) {
        const icon = markerRef.current.getIcon() as google.maps.Symbol;
        markerRef.current.setIcon({
          ...icon,
          rotation: location.heading
        });
      }

      // Pan map to new position
      mapInstanceRef.current.panTo(newPosition);

      // Recalculate route if destination exists
      if (destination) {
        calculateRoute();
      }
    }
  }, [location]);

  const calculateRoute = () => {
    if (!destination || !mapInstanceRef.current || !directionsRendererRef.current) {
      return;
    }

    const directionsService = new google.maps.DirectionsService();

    directionsService.route(
      {
        origin: { lat: location.latitude, lng: location.longitude },
        destination: { lat: destination.latitude, lng: destination.longitude },
        travelMode: google.maps.TravelMode.DRIVING
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          directionsRendererRef.current?.setDirections(result);

          // Fit map bounds to include both points
          const bounds = new google.maps.LatLngBounds();
          bounds.extend({ lat: location.latitude, lng: location.longitude });
          bounds.extend({ lat: destination.latitude, lng: destination.longitude });
          mapInstanceRef.current?.fitBounds(bounds);
        }
      }
    );
  };

  return (
    <div 
      ref={mapRef} 
      className="w-full h-[400px] rounded-lg overflow-hidden shadow-md"
    />
  );
}