import React from 'react';
import { useVehicleAnalytics } from '../hooks/useVehicleAnalytics';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';

interface VehicleAnalyticsProps {
  vehicleId: string;
}

export function VehicleAnalytics({ vehicleId }: VehicleAnalyticsProps) {
  const { getVehicleAnalytics, loading, error } = useVehicleAnalytics();
  const [analytics, setAnalytics] = React.useState(null);

  React.useEffect(() => {
    loadAnalytics();
  }, [vehicleId]);

  const loadAnalytics = async () => {
    const data = await getVehicleAnalytics(vehicleId);
    if (data) {
      setAnalytics(data);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <ErrorMessage message={error} />;
  }

  if (!analytics) {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="text-sm font-medium text-gray-500">Toplam Kiralama</h3>
          <p className="text-2xl font-bold">{analytics.total_bookings}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="text-sm font-medium text-gray-500">Toplam Gelir</h3>
          <p className="text-2xl font-bold">{analytics.total_revenue}₺</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="text-sm font-medium text-gray-500">Toplam Kiralanan Saat</h3>
          <p className="text-2xl font-bold">{analytics.total_hours_rented}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="text-sm font-medium text-gray-500">Ortalama Puan</h3>
          <p className="text-2xl font-bold">{analytics.average_rating.toFixed(1)}</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">Aylık İstatistikler</h3>
        <div className="space-y-4">
          {analytics.monthly_stats?.map((stat) => (
            <div key={stat.month} className="flex items-center justify-between">
              <div className="w-24">
                <p className="text-sm text-gray-600">
                  {new Date(stat.month).toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' })}
                </p>
              </div>
              
              <div className="flex-1 px-4">
                <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600"
                    style={{
                      width: `${(stat.bookings / Math.max(...analytics.monthly_stats.map(s => s.bookings))) * 100}%`
                    }}
                  />
                </div>
              </div>
              
              <div className="w-32 text-right">
                <p className="font-medium">{stat.bookings} kiralama</p>
                <p className="text-sm text-gray-600">{stat.revenue}₺</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}