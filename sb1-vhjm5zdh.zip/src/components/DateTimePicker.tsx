import React from 'react';

interface DateTimePickerProps {
  selectedDate: string;
  selectedTime: string;
  duration: number;
  minDate?: string;
  maxDate?: string;
  onDateChange: (date: string) => void;
  onTimeChange: (time: string) => void;
  onDurationChange: (duration: number) => void;
}

export function DateTimePicker({
  selectedDate,
  selectedTime,
  duration,
  minDate = new Date().toISOString().split('T')[0],
  maxDate,
  onDateChange,
  onTimeChange,
  onDurationChange
}: DateTimePickerProps) {
  const timeSlots = Array.from({ length: 24 }, (_, i) => {
    const hour = i.toString().padStart(2, '0');
    return `${hour}:00`;
  });

  const durationOptions = [1, 2, 3, 4, 6, 8, 12, 24];

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Tarih
        </label>
        <input
          type="date"
          className="w-full p-3 border rounded-lg"
          value={selectedDate}
          min={minDate}
          max={maxDate}
          onChange={(e) => onDateChange(e.target.value)}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Başlangıç Saati
        </label>
        <select
          className="w-full p-3 border rounded-lg"
          value={selectedTime}
          onChange={(e) => onTimeChange(e.target.value)}
        >
          {timeSlots.map((time) => (
            <option key={time} value={time}>
              {time}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Kiralama Süresi
        </label>
        <select
          className="w-full p-3 border rounded-lg"
          value={duration}
          onChange={(e) => onDurationChange(Number(e.target.value))}
        >
          {durationOptions.map((hours) => (
            <option key={hours} value={hours}>
              {hours} saat
            </option>
          ))}
        </select>
      </div>

      <div className="p-4 bg-gray-50 rounded-lg">
        <p className="text-sm text-gray-600">
          Seçilen Zaman: {selectedDate} {selectedTime}
        </p>
        <p className="text-sm text-gray-600">
          Bitiş Zamanı:{' '}
          {new Date(new Date(`${selectedDate} ${selectedTime}`).getTime() + duration * 60 * 60 * 1000)
            .toLocaleString('tr-TR', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
        </p>
      </div>
    </div>
  );
}