import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../hooks/useNotifications';
import { LoadingSpinner } from './LoadingSpinner';

export function NotificationsDropdown({ onClose }: { onClose: () => void }) {
  const navigate = useNavigate();
  const { notifications, loading, error, markAsRead, markAllAsRead } = useNotifications();

  const handleNotificationClick = (notification: any) => {
    markAsRead(notification.id);
    
    // Navigate based on notification type and data
    switch (notification.type) {
      case 'rental_request':
        navigate('/rental-requests');
        break;
      case 'request_accepted':
      case 'request_rejected':
        navigate('/bookings');
        break;
      default:
        break;
    }
    
    onClose();
  };

  if (loading) {
    return (
      <div className="w-96 max-h-[32rem] overflow-y-auto bg-white rounded-lg shadow-lg py-4">
        <div className="flex justify-center p-4">
          <LoadingSpinner />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-96 bg-white rounded-lg shadow-lg p-4">
        <p className="text-red-500 text-center">{error}</p>
      </div>
    );
  }

  return (
    <div className="w-96 max-h-[32rem] overflow-y-auto bg-white rounded-lg shadow-lg">
      <div className="p-4 border-b flex justify-between items-center">
        <h2 className="text-lg font-semibold">Bildirimler</h2>
        {notifications.some(n => !n.read) && (
          <button
            className="text-sm text-blue-600 hover:text-blue-700"
            onClick={markAllAsRead}
          >
            Tümünü Okundu İşaretle
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="p-4 text-center text-gray-500">
          Henüz bildiriminiz bulunmuyor
        </div>
      ) : (
        <div className="divide-y">
          {notifications.map((notification) => (
            <button
              key={notification.id}
              className={`w-full text-left p-4 hover:bg-gray-50 transition-colors ${
                !notification.read ? 'bg-blue-50' : ''
              }`}
              onClick={() => handleNotificationClick(notification)}
            >
              <h3 className="font-semibold mb-1">{notification.title}</h3>
              <p className="text-sm text-gray-600">{notification.message}</p>
              <p className="text-xs text-gray-400 mt-2">
                {new Date(notification.created_at).toLocaleString()}
              </p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}