import React from 'react';
import { useReviews } from '../hooks/useReviews';
import { LoadingSpinner } from './LoadingSpinner';

interface ReviewListProps {
  userId: string;
  type?: 'renter_review' | 'owner_review';
}

export function ReviewList({ userId, type }: ReviewListProps) {
  const { getReviews } = useReviews();
  const [reviews, setReviews] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [stats, setStats] = React.useState<any>(null);

  React.useEffect(() => {
    loadReviews();
  }, [userId, type]);

  const loadReviews = async () => {
    const data = await getReviews(userId, type);
    setReviews(data || []);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center p-4">
        <LoadingSpinner />
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center text-gray-500 p-4">
        Henüz değerlendirme yapılmamış
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <div key={review.id} className="bg-white p-4 rounded-lg shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <div>
              <p className="font-semibold">{review.reviewer.full_name}</p>
              <div className="flex items-center">
                <div className="flex text-yellow-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className={i < review.rating ? 'text-yellow-400' : 'text-gray-300'}>
                      ★
                    </span>
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">
                  {new Date(review.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
          {review.comment && (
            <p className="text-gray-700 mt-2">{review.comment}</p>
          )}
        </div>
      ))}
    </div>
  );
}