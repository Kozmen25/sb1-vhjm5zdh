import React from 'react';
import { useDriverReviews } from '../hooks/useDriverReviews';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';

interface DriverReviewsProps {
  driverId: string;
}

export function DriverReviews({ driverId }: DriverReviewsProps) {
  const { getDriverReviews, getDriverStats, loading, error } = useDriverReviews();
  const [reviews, setReviews] = React.useState([]);
  const [stats, setStats] = React.useState(null);

  React.useEffect(() => {
    loadReviewsAndStats();
  }, [driverId]);

  const loadReviewsAndStats = async () => {
    const [reviewsData, statsData] = await Promise.all([
      getDriverReviews(driverId),
      getDriverStats(driverId)
    ]);

    setReviews(reviewsData);
    setStats(statsData);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <ErrorMessage message={error} />;
  }

  return (
    <div className="space-y-6">
      {stats && (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">Değerlendirmeler</h3>
              <p className="text-gray-600">{stats.total_reviews} değerlendirme</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold">{stats.average_rating.toFixed(1)}</p>
              <div className="flex text-yellow-400">
                {[1, 2, 3, 4, 5].map((star) => (
                  <span
                    key={star}
                    className={star <= Math.round(stats.average_rating) ? 'text-yellow-400' : 'text-gray-300'}
                  >
                    ★
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => {
              const count = stats.rating_distribution[rating];
              const percentage = (count / stats.total_reviews) * 100 || 0;
              
              return (
                <div key={rating} className="flex items-center">
                  <span className="w-8 text-sm text-gray-600">{rating}</span>
                  <div className="flex-1 h-2 mx-2 bg-gray-200 rounded">
                    <div
                      className="h-full bg-yellow-400 rounded"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="w-12 text-sm text-gray-600">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="font-semibold">{review.reviewer.full_name}</p>
                <div className="flex text-yellow-400">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span
                      key={star}
                      className={star <= review.rating ? 'text-yellow-400' : 'text-gray-300'}
                    >
                      ★
                    </span>
                  ))}
                </div>
              </div>
              <p className="text-sm text-gray-500">
                {new Date(review.created_at).toLocaleDateString()}
              </p>
            </div>
            {review.comment && (
              <p className="text-gray-700 mt-2">{review.comment}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}