import React from 'react';

interface LocationPickerProps {
  pickupLocation: string;
  dropoffLocation: string;
  onPickupLocationChange: (location: string) => void;
  onDropoffLocationChange: (location: string) => void;
}

export function LocationPicker({
  pickupLocation,
  dropoffLocation,
  onPickupLocationChange,
  onDropoffLocationChange
}: LocationPickerProps) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Alış Noktası
        </label>
        <input
          type="text"
          className="w-full p-3 border rounded-lg"
          placeholder="Örn: Kadıköy, İstanbul"
          value={pickupLocation}
          onChange={(e) => onPickupLocationChange(e.target.value)}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Teslim Noktası
        </label>
        <input
          type="text"
          className="w-full p-3 border rounded-lg"
          placeholder="Örn: Beşiktaş, İstanbul"
          value={dropoffLocation}
          onChange={(e) => onDropoffLocationChange(e.target.value)}
        />
      </div>

      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
        <button
          type="button"
          className="text-blue-600 hover:text-blue-700"
          onClick={() => onDropoffLocationChange(pickupLocation)}
        >
          Teslim noktası olarak alış noktasını kullan
        </button>
      </div>
    </div>
  );
}