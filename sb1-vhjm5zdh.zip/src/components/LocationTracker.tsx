import React, { useEffect, useState } from 'react';
import { useLocationTracking } from '../hooks/useLocationTracking';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';

interface LocationTrackerProps {
  driverId: string;
  bookingId: string;
  onLocationUpdate?: (location: {
    latitude: number;
    longitude: number;
    heading?: number;
    speed?: number;
  }) => void;
}

export function LocationTracker({
  driverId,
  bookingId,
  onLocationUpdate
}: LocationTrackerProps) {
  const { getLatestLocation, subscribeToLocationUpdates } = useLocationTracking();
  const [location, setLocation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadInitialLocation();
    const unsubscribe = subscribeToLocationUpdates(
      driverId,
      bookingId,
      handleLocationUpdate
    );

    return () => {
      unsubscribe();
    };
  }, [driverId, bookingId]);

  const loadInitialLocation = async () => {
    try {
      const data = await getLatestLocation(driverId, bookingId);
      if (data) {
        setLocation(data);
        onLocationUpdate?.(data);
      }
    } catch (err) {
      setError('Konum bilgisi yüklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleLocationUpdate = (newLocation) => {
    setLocation(newLocation);
    onLocationUpdate?.(newLocation);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <ErrorMessage message={error} />;
  }

  if (!location) {
    return (
      <div className="text-center text-gray-600">
        Sürücü konumu henüz paylaşılmadı
      </div>
    );
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">Sürücü Konumu</h3>
      
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-gray-600">Enlem</span>
          <span className="font-medium">{location.latitude}</span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-gray-600">Boylam</span>
          <span className="font-medium">{location.longitude}</span>
        </div>
        
        {location.speed && (
          <div className="flex justify-between">
            <span className="text-gray-600">Hız</span>
            <span className="font-medium">{location.speed} km/s</span>
          </div>
        )}
        
        <div className="flex justify-between">
          <span className="text-gray-600">Son Güncelleme</span>
          <span className="font-medium">
            {new Date(location.updated_at).toLocaleTimeString()}
          </span>
        </div>
      </div>
    </div>
  );
}