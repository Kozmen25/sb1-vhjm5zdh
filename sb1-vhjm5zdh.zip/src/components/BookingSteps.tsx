import React from 'react';

interface BookingStepsProps {
  currentStep: number;
}

const steps = [
  { id: 1, title: 'Araç Seçimi' },
  { id: 2, title: 'Tarih ve Süre' },
  { id: 3, title: 'Konum Bilgileri' },
  { id: 4, title: 'Ödeme' }
];

export function BookingSteps({ currentStep }: BookingStepsProps) {
  return (
    <div className="py-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center">
          {steps.map((step, index) => (
            <React.Fragment key={step.id}>
              {/* Step circle */}
              <div className="relative flex items-center justify-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                    step.id <= currentStep
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : 'border-gray-300 bg-white text-gray-500'
                  }`}
                >
                  {step.id < currentStep ? (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  ) : (
                    <span className="text-sm font-medium">{step.id}</span>
                  )}
                </div>
                <div className="absolute -bottom-6 w-32 text-center text-sm">
                  <span
                    className={step.id <= currentStep ? 'text-blue-600' : 'text-gray-500'}
                  >
                    {step.title}
                  </span>
                </div>
              </div>
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div
                  className={`flex-1 h-0.5 ${
                    step.id < currentStep ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}