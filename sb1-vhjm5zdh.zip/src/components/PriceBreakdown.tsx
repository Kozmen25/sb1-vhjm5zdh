import React from 'react';

interface PriceBreakdownProps {
  hourlyRate: number;
  duration: number;
  extras?: Array<{
    name: string;
    price: number;
  }>;
}

export function PriceBreakdown({ hourlyRate, duration, extras = [] }: PriceBreakdownProps) {
  const basePrice = hourlyRate * duration;
  const extrasTotal = extras.reduce((sum, extra) => sum + extra.price, 0);
  const total = basePrice + extrasTotal;

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">Fiyat Detayı</h3>
      
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-gray-600">Saatlik Ücret</span>
          <span>{hourlyRate}₺</span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-gray-600">Süre</span>
          <span>{duration} saat</span>
        </div>
        
        <div className="flex justify-between font-medium">
          <span>Ara Toplam</span>
          <span>{basePrice}₺</span>
        </div>

        {extras.length > 0 && (
          <>
            <div className="border-t pt-2 mt-2">
              <p className="text-sm text-gray-600 mb-2">Ekstra Hizmetler</p>
              {extras.map((extra, index) => (
                <div key={index} className="flex justify-between text-sm">
                  <span className="text-gray-600">{extra.name}</span>
                  <span>{extra.price}₺</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between font-medium">
              <span>Ekstra Hizmetler Toplamı</span>
              <span>{extrasTotal}₺</span>
            </div>
          </>
        )}

        <div className="border-t pt-2 mt-2">
          <div className="flex justify-between text-lg font-bold">
            <span>Toplam</span>
            <span>{total}₺</span>
          </div>
        </div>
      </div>
    </div>
  );
}