export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string
          phone: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          email: string
          full_name: string
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      vehicles: {
        Row: {
          id: string
          name: string
          type: string
          price_per_hour: number
          description: string | null
          features: Json | null
          available: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          type: string
          price_per_hour: number
          description?: string | null
          features?: Json | null
          available?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          type?: string
          price_per_hour?: number
          description?: string | null
          features?: Json | null
          available?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      drivers: {
        Row: {
          id: string
          user_id: string
          rating: number
          trips_count: number
          languages: string[]
          bio: string | null
          available: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          rating?: number
          trips_count?: number
          languages?: string[]
          bio?: string | null
          available?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          rating?: number
          trips_count?: number
          languages?: string[]
          bio?: string | null
          available?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      bookings: {
        Row: {
          id: string
          user_id: string
          vehicle_id: string
          driver_id: string
          start_time: string
          duration_hours: number
          pickup_location: string
          dropoff_location: string
          status: string
          total_amount: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          vehicle_id: string
          driver_id: string
          start_time: string
          duration_hours: number
          pickup_location: string
          dropoff_location: string
          status?: string
          total_amount: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          vehicle_id?: string
          driver_id?: string
          start_time?: string
          duration_hours?: number
          pickup_location?: string
          dropoff_location?: string
          status?: string
          total_amount?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}