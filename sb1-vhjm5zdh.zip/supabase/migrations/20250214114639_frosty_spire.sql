/*
  # Add driver review system

  1. New Tables
    - driver_reviews
      - id (uuid, primary key)
      - booking_id (uuid, references bookings)
      - reviewer_id (uuid, references users)
      - driver_id (uuid, references drivers)
      - rating (integer)
      - comment (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on driver_reviews table
    - Add policies for authenticated users
*/

-- Create driver reviews table
CREATE TABLE IF NOT EXISTS driver_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  reviewer_id uuid REFERENCES users(id) ON DELETE CASCADE,
  driver_id uuid REFERENCES drivers(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE driver_reviews ENABLE ROW LEVEL SECURITY;

-- Policies for driver reviews
CREATE POLICY "Anyone can read driver reviews"
  ON driver_reviews
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create reviews for their bookings"
  ON driver_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (
    reviewer_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_id
      AND bookings.user_id = auth.uid()
      AND bookings.status = 'completed'
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_driver_reviews_booking_id ON driver_reviews(booking_id);
CREATE INDEX IF NOT EXISTS idx_driver_reviews_reviewer_id ON driver_reviews(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_driver_reviews_driver_id ON driver_reviews(driver_id);

-- Function to calculate driver rating
CREATE OR REPLACE FUNCTION calculate_driver_rating(
  p_driver_id uuid
) RETURNS numeric AS $$
DECLARE
  v_rating numeric;
BEGIN
  SELECT AVG(rating)::numeric(3,2)
  INTO v_rating
  FROM driver_reviews
  WHERE driver_id = p_driver_id;
  
  RETURN COALESCE(v_rating, 0);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get driver review stats
CREATE OR REPLACE FUNCTION get_driver_review_stats(
  p_driver_id uuid
) RETURNS jsonb AS $$
DECLARE
  v_stats jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_reviews', COUNT(*),
    'average_rating', AVG(rating)::numeric(3,2),
    'rating_distribution', jsonb_build_object(
      '5', COUNT(*) FILTER (WHERE rating = 5),
      '4', COUNT(*) FILTER (WHERE rating = 4),
      '3', COUNT(*) FILTER (WHERE rating = 3),
      '2', COUNT(*) FILTER (WHERE rating = 2),
      '1', COUNT(*) FILTER (WHERE rating = 1)
    )
  )
  INTO v_stats
  FROM driver_reviews
  WHERE driver_id = p_driver_id;
  
  RETURN v_stats;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function to update driver rating
CREATE OR REPLACE FUNCTION update_driver_rating() RETURNS trigger AS $$
BEGIN
  UPDATE drivers
  SET 
    rating = calculate_driver_rating(NEW.driver_id),
    updated_at = now()
  WHERE id = NEW.driver_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for driver reviews
CREATE TRIGGER update_driver_rating_trigger
AFTER INSERT OR UPDATE ON driver_reviews
FOR EACH ROW
EXECUTE FUNCTION update_driver_rating();