/*
  # Add rental requests and vehicle ownership support

  1. Changes to Existing Tables
    - Add owner_id to vehicles table
    - Add foreign key constraint to users table

  2. New Tables
    - rental_requests
      - id (uuid, primary key)
      - vehicle_id (uuid, references vehicles)
      - user_id (uuid, references users)
      - start_time (timestamptz)
      - duration_hours (integer)
      - pickup_location (text)
      - dropoff_location (text)
      - status (text)
      - total_amount (decimal)
      - message (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  3. Security
    - Enable RLS on rental_requests table
    - Add policies for vehicle owners and renters
*/

-- Add owner_id to vehicles table
ALTER TABLE vehicles 
ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES users(id);

-- Create rental_requests table
CREATE TABLE IF NOT EXISTS rental_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid REFERENCES vehicles(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  start_time timestamptz NOT NULL,
  duration_hours integer NOT NULL,
  pickup_location text NOT NULL,
  dropoff_location text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  total_amount decimal NOT NULL,
  message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled'))
);

-- Enable RLS
ALTER TABLE rental_requests ENABLE ROW LEVEL SECURITY;

-- Policies for rental_requests
CREATE POLICY "Vehicle owners can read requests for their vehicles"
  ON rental_requests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM vehicles
      WHERE vehicles.id = rental_requests.vehicle_id
      AND vehicles.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can read their own requests"
  ON rental_requests
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create new requests"
  ON rental_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Vehicle owners can update request status"
  ON rental_requests
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM vehicles
      WHERE vehicles.id = rental_requests.vehicle_id
      AND vehicles.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM vehicles
      WHERE vehicles.id = rental_requests.vehicle_id
      AND vehicles.owner_id = auth.uid()
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_rental_requests_vehicle_id ON rental_requests(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_rental_requests_user_id ON rental_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_rental_requests_status ON rental_requests(status);
CREATE INDEX IF NOT EXISTS idx_vehicles_owner_id ON vehicles(owner_id);

-- Update vehicles policies to include owner_id checks
CREATE POLICY "Vehicle owners can update their vehicles"
  ON vehicles
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Vehicle owners can delete their vehicles"
  ON vehicles
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());