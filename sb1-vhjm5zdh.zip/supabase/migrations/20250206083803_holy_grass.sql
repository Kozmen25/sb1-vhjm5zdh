/*
  # Update users table RLS policies

  1. Changes
    - Add policy to allow authenticated users to insert their own data
    - Add policy to allow authenticated users to update their own data
    - Keep existing policy for reading own data

  2. Security
    - Users can only insert/update their own data
    - Users can only read their own data
    - Maintains data isolation between users
*/

-- Allow users to insert their own data
CREATE POLICY "Users can insert own data"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Allow users to update their own data
CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);