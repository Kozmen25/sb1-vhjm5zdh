/*
  # Add vehicle analytics system

  1. New Tables
    - vehicle_analytics
      - id (uuid, primary key)
      - vehicle_id (uuid, references vehicles)
      - total_bookings (integer)
      - total_revenue (decimal)
      - total_hours_rented (integer)
      - average_rating (decimal)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on vehicle_analytics table
    - Add policies for vehicle owners
*/

-- Create vehicle analytics table
CREATE TABLE IF NOT EXISTS vehicle_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid REFERENCES vehicles(id) ON DELETE CASCADE,
  total_bookings integer DEFAULT 0,
  total_revenue decimal DEFAULT 0,
  total_hours_rented integer DEFAULT 0,
  average_rating decimal DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE vehicle_analytics ENABLE ROW LEVEL SECURITY;

-- Policies for vehicle analytics
CREATE POLICY "Vehicle owners can read analytics"
  ON vehicle_analytics
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM vehicles
      WHERE vehicles.id = vehicle_analytics.vehicle_id
      AND vehicles.owner_id = auth.uid()
    )
  );

-- Function to update vehicle analytics
CREATE OR REPLACE FUNCTION update_vehicle_analytics() RETURNS trigger AS $$
BEGIN
  -- For new bookings
  IF TG_OP = 'INSERT' THEN
    INSERT INTO vehicle_analytics (vehicle_id)
    VALUES (NEW.vehicle_id)
    ON CONFLICT (vehicle_id) DO
    UPDATE SET
      total_bookings = vehicle_analytics.total_bookings + 1,
      total_revenue = vehicle_analytics.total_revenue + NEW.total_amount,
      total_hours_rented = vehicle_analytics.total_hours_rented + NEW.duration_hours,
      updated_at = now();
  
  -- For updated bookings
  ELSIF TG_OP = 'UPDATE' THEN
    UPDATE vehicle_analytics
    SET
      total_revenue = CASE
        WHEN NEW.status = 'completed' AND OLD.status != 'completed'
        THEN total_revenue + NEW.total_amount
        WHEN NEW.status != 'completed' AND OLD.status = 'completed'
        THEN total_revenue - NEW.total_amount
        ELSE total_revenue
      END,
      updated_at = now()
    WHERE vehicle_id = NEW.vehicle_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers for bookings
CREATE TRIGGER update_vehicle_analytics_on_insert
AFTER INSERT ON bookings
FOR EACH ROW
EXECUTE FUNCTION update_vehicle_analytics();

CREATE TRIGGER update_vehicle_analytics_on_update
AFTER UPDATE OF status ON bookings
FOR EACH ROW
EXECUTE FUNCTION update_vehicle_analytics();

-- Function to get vehicle analytics
CREATE OR REPLACE FUNCTION get_vehicle_analytics(
  p_vehicle_id uuid
) RETURNS jsonb AS $$
DECLARE
  v_analytics jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_bookings', total_bookings,
    'total_revenue', total_revenue,
    'total_hours_rented', total_hours_rented,
    'average_rating', average_rating,
    'monthly_stats', (
      SELECT jsonb_agg(
        jsonb_build_object(
          'month', date_trunc('month', b.created_at),
          'bookings', COUNT(*),
          'revenue', SUM(b.total_amount),
          'hours_rented', SUM(b.duration_hours)
        )
      )
      FROM bookings b
      WHERE b.vehicle_id = p_vehicle_id
      AND b.created_at >= date_trunc('month', now()) - interval '11 months'
      GROUP BY date_trunc('month', b.created_at)
      ORDER BY date_trunc('month', b.created_at)
    )
  )
  INTO v_analytics
  FROM vehicle_analytics
  WHERE vehicle_id = p_vehicle_id;

  RETURN v_analytics;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;