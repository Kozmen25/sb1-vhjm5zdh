/*
  # Add payment system

  1. New Tables
    - payments
      - id (uuid, primary key)
      - booking_id (uuid, references bookings)
      - amount (decimal)
      - currency (text)
      - status (text)
      - stripe_payment_intent_id (text)
      - stripe_client_secret (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on payments table
    - Add policies for authenticated users
*/

-- Create payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  amount decimal NOT NULL,
  currency text NOT NULL DEFAULT 'try',
  status text NOT NULL DEFAULT 'pending',
  stripe_payment_intent_id text,
  stripe_client_secret text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'processing', 'succeeded', 'failed', 'refunded'))
);

-- Enable RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Policies for payments
CREATE POLICY "Users can read their own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = payments.booking_id
      AND (
        bookings.user_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM vehicles
          WHERE vehicles.id = bookings.vehicle_id
          AND vehicles.owner_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "Users can create payments for their bookings"
  ON payments
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_id
      AND bookings.user_id = auth.uid()
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payments_booking_id ON payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at);

-- Function to create payment
CREATE OR REPLACE FUNCTION create_payment(
  p_booking_id uuid,
  p_amount decimal,
  p_currency text DEFAULT 'try',
  p_stripe_payment_intent_id text DEFAULT NULL,
  p_stripe_client_secret text DEFAULT NULL
) RETURNS uuid AS $$
DECLARE
  v_payment_id uuid;
BEGIN
  INSERT INTO payments (
    booking_id,
    amount,
    currency,
    stripe_payment_intent_id,
    stripe_client_secret
  )
  VALUES (
    p_booking_id,
    p_amount,
    p_currency,
    p_stripe_payment_intent_id,
    p_stripe_client_secret
  )
  RETURNING id INTO v_payment_id;
  
  RETURN v_payment_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update payment status
CREATE OR REPLACE FUNCTION update_payment_status(
  p_payment_id uuid,
  p_status text
) RETURNS void AS $$
BEGIN
  UPDATE payments
  SET 
    status = p_status,
    updated_at = now()
  WHERE id = p_payment_id
  AND EXISTS (
    SELECT 1 FROM bookings
    WHERE bookings.id = payments.booking_id
    AND bookings.user_id = auth.uid()
  );
  
  -- Update booking status if payment is successful
  IF p_status = 'succeeded' THEN
    UPDATE bookings
    SET status = 'confirmed'
    WHERE id = (
      SELECT booking_id 
      FROM payments 
      WHERE id = p_payment_id
    );
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;