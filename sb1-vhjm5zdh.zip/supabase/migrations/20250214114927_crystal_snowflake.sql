/*
  # Add location tracking system

  1. New Tables
    - driver_locations
      - id (uuid, primary key)
      - driver_id (uuid, references drivers)
      - booking_id (uuid, references bookings)
      - latitude (decimal)
      - longitude (decimal)
      - heading (decimal)
      - speed (decimal)
      - created_at (timestamptz)

  2. Security
    - Enable RLS on driver_locations table
    - Add policies for location tracking
*/

-- Create driver_locations table
CREATE TABLE IF NOT EXISTS driver_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid REFERENCES drivers(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  latitude decimal NOT NULL,
  longitude decimal NOT NULL,
  heading decimal,
  speed decimal,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE driver_locations ENABLE ROW LEVEL SECURITY;

-- Policies for driver_locations
CREATE POLICY "Drivers can insert their own location"
  ON driver_locations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM drivers
      WHERE drivers.id = driver_id
      AND drivers.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can read driver location for their bookings"
  ON driver_locations
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_id
      AND (
        bookings.user_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM drivers
          WHERE drivers.id = driver_locations.driver_id
          AND drivers.user_id = auth.uid()
        )
      )
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_driver_locations_driver_id ON driver_locations(driver_id);
CREATE INDEX IF NOT EXISTS idx_driver_locations_booking_id ON driver_locations(booking_id);
CREATE INDEX IF NOT EXISTS idx_driver_locations_created_at ON driver_locations(created_at);

-- Function to update driver location
CREATE OR REPLACE FUNCTION update_driver_location(
  p_driver_id uuid,
  p_booking_id uuid,
  p_latitude decimal,
  p_longitude decimal,
  p_heading decimal DEFAULT NULL,
  p_speed decimal DEFAULT NULL
) RETURNS uuid AS $$
DECLARE
  v_location_id uuid;
BEGIN
  INSERT INTO driver_locations (
    driver_id,
    booking_id,
    latitude,
    longitude,
    heading,
    speed
  )
  VALUES (
    p_driver_id,
    p_booking_id,
    p_latitude,
    p_longitude,
    p_heading,
    p_speed
  )
  RETURNING id INTO v_location_id;
  
  RETURN v_location_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get latest driver location
CREATE OR REPLACE FUNCTION get_latest_driver_location(
  p_driver_id uuid,
  p_booking_id uuid
) RETURNS jsonb AS $$
DECLARE
  v_location jsonb;
BEGIN
  SELECT jsonb_build_object(
    'latitude', latitude,
    'longitude', longitude,
    'heading', heading,
    'speed', speed,
    'updated_at', created_at
  )
  INTO v_location
  FROM driver_locations
  WHERE driver_id = p_driver_id
  AND booking_id = p_booking_id
  ORDER BY created_at DESC
  LIMIT 1;
  
  RETURN v_location;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;