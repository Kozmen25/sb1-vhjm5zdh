/*
  # Add user_type to users table

  1. Changes
    - Add user_type column to users table
    - Add check constraint for valid user types
    - Update RLS policies
*/

-- Add user_type column if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'user_type'
  ) THEN
    ALTER TABLE users 
    ADD COLUMN user_type text NOT NULL DEFAULT 'renter';

    -- Add check constraint for valid user types
    ALTER TABLE users 
    ADD CONSTRAINT valid_user_type 
    CHECK (user_type IN ('renter', 'renter_with_driver', 'vehicle_owner'));
  END IF;
END $$;

-- Update existing policies to include user_type
DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Users can insert own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;

-- Recreate policies with user_type
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own data"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);