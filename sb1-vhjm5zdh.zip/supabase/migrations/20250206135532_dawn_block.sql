/*
  # Add review and rating system

  1. New Tables
    - reviews
      - id (uuid, primary key)
      - booking_id (uuid, references bookings)
      - reviewer_id (uuid, references users)
      - reviewee_id (uuid, references users)
      - vehicle_id (uuid, references vehicles)
      - rating (integer)
      - comment (text)
      - type (text) - 'renter_review' or 'owner_review'
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on reviews table
    - Add policies for users to manage their reviews
*/

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  reviewer_id uuid REFERENCES users(id) ON DELETE CASCADE,
  reviewee_id uuid REFERENCES users(id) ON DELETE CASCADE,
  vehicle_id uuid REFERENCES vehicles(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  type text NOT NULL CHECK (type IN ('renter_review', 'owner_review')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Policies for reviews
CREATE POLICY "Anyone can read reviews"
  ON reviews
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create reviews for their bookings"
  ON reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (
    reviewer_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_id
      AND (
        (type = 'renter_review' AND bookings.user_id = auth.uid()) OR
        (type = 'owner_review' AND EXISTS (
          SELECT 1 FROM vehicles
          WHERE vehicles.id = bookings.vehicle_id
          AND vehicles.owner_id = auth.uid()
        ))
      )
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_reviews_booking_id ON reviews(booking_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewer_id ON reviews(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewee_id ON reviews(reviewee_id);
CREATE INDEX IF NOT EXISTS idx_reviews_vehicle_id ON reviews(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_reviews_type ON reviews(type);

-- Create function to calculate average rating
CREATE OR REPLACE FUNCTION calculate_average_rating(
  p_user_id uuid,
  p_type text DEFAULT NULL
) RETURNS numeric AS $$
DECLARE
  v_average numeric;
BEGIN
  SELECT AVG(rating)::numeric(3,2)
  INTO v_average
  FROM reviews
  WHERE reviewee_id = p_user_id
  AND (p_type IS NULL OR type = p_type);
  
  RETURN COALESCE(v_average, 0);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get review counts
CREATE OR REPLACE FUNCTION get_review_counts(
  p_user_id uuid,
  p_type text DEFAULT NULL
) RETURNS jsonb AS $$
DECLARE
  v_counts jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total', COUNT(*),
    'ratings', jsonb_build_object(
      '1', SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END),
      '2', SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END),
      '3', SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END),
      '4', SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END),
      '5', SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END)
    )
  )
  INTO v_counts
  FROM reviews
  WHERE reviewee_id = p_user_id
  AND (p_type IS NULL OR type = p_type);
  
  RETURN v_counts;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger function to update user ratings
CREATE OR REPLACE FUNCTION update_user_ratings() RETURNS trigger AS $$
BEGIN
  -- Update user's average rating
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    UPDATE users
    SET 
      average_rating = calculate_average_rating(NEW.reviewee_id),
      review_count = (get_review_counts(NEW.reviewee_id)->>'total')::integer,
      updated_at = now()
    WHERE id = NEW.reviewee_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for reviews
CREATE TRIGGER update_user_ratings_trigger
AFTER INSERT OR UPDATE ON reviews
FOR EACH ROW
EXECUTE FUNCTION update_user_ratings();