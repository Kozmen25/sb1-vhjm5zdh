/*
  # Add notifications system

  1. New Tables
    - notifications
      - id (uuid, primary key)
      - user_id (uuid, references users)
      - title (text)
      - message (text)
      - type (text)
      - read (boolean)
      - data (jsonb)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on notifications table
    - Add policies for users to manage their notifications
*/

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL,
  read boolean DEFAULT false,
  data jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_notification_type CHECK (
    type IN ('rental_request', 'request_accepted', 'request_rejected', 'payment_received', 'booking_reminder')
  )
);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Policies for notifications
CREATE POLICY "Users can read own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own notifications"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at);

-- Create function to create notification
CREATE OR REPLACE FUNCTION create_notification(
  p_user_id uuid,
  p_title text,
  p_message text,
  p_type text,
  p_data jsonb DEFAULT NULL
) RETURNS uuid AS $$
DECLARE
  v_notification_id uuid;
BEGIN
  INSERT INTO notifications (user_id, title, message, type, data)
  VALUES (p_user_id, p_title, p_message, p_type, p_data)
  RETURNING id INTO v_notification_id;
  
  RETURN v_notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to mark notification as read
CREATE OR REPLACE FUNCTION mark_notification_read(
  p_notification_id uuid
) RETURNS void AS $$
BEGIN
  UPDATE notifications
  SET 
    read = true,
    updated_at = now()
  WHERE id = p_notification_id
  AND user_id = auth.uid();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger function for rental request notifications
CREATE OR REPLACE FUNCTION notify_rental_request() RETURNS trigger AS $$
DECLARE
  v_vehicle_owner_id uuid;
  v_vehicle_name text;
  v_requester_name text;
BEGIN
  -- Get vehicle owner and name
  SELECT owner_id, name 
  INTO v_vehicle_owner_id, v_vehicle_name
  FROM vehicles 
  WHERE id = NEW.vehicle_id;

  -- Get requester name
  SELECT full_name 
  INTO v_requester_name
  FROM users 
  WHERE id = NEW.user_id;

  -- Create notification for vehicle owner
  PERFORM create_notification(
    v_vehicle_owner_id,
    'Yeni Kiralama Talebi',
    v_requester_name || ' kullanıcısı ' || v_vehicle_name || ' aracınız için kiralama talebinde bulundu.',
    'rental_request',
    jsonb_build_object(
      'request_id', NEW.id,
      'vehicle_id', NEW.vehicle_id,
      'requester_id', NEW.user_id
    )
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new rental requests
CREATE TRIGGER rental_request_notification
AFTER INSERT ON rental_requests
FOR EACH ROW
EXECUTE FUNCTION notify_rental_request();

-- Create trigger function for rental request status updates
CREATE OR REPLACE FUNCTION notify_rental_request_status() RETURNS trigger AS $$
DECLARE
  v_vehicle_name text;
BEGIN
  -- Get vehicle name
  SELECT name 
  INTO v_vehicle_name
  FROM vehicles 
  WHERE id = NEW.vehicle_id;

  -- Create notification for requester
  IF NEW.status = 'accepted' THEN
    PERFORM create_notification(
      NEW.user_id,
      'Kiralama Talebi Kabul Edildi',
      v_vehicle_name || ' aracı için kiralama talebiniz kabul edildi.',
      'request_accepted',
      jsonb_build_object(
        'request_id', NEW.id,
        'vehicle_id', NEW.vehicle_id
      )
    );
  ELSIF NEW.status = 'rejected' THEN
    PERFORM create_notification(
      NEW.user_id,
      'Kiralama Talebi Reddedildi',
      v_vehicle_name || ' aracı için kiralama talebiniz reddedildi.',
      'request_rejected',
      jsonb_build_object(
        'request_id', NEW.id,
        'vehicle_id', NEW.vehicle_id
      )
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for rental request status updates
CREATE TRIGGER rental_request_status_notification
AFTER UPDATE OF status ON rental_requests
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION notify_rental_request_status();