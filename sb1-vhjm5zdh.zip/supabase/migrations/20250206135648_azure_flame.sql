/*
  # Add chat system

  1. New Tables
    - chats
      - id (uuid, primary key)
      - sender_id (uuid, references users)
      - recipient_id (uuid, references users)
      - booking_id (uuid, references bookings)
      - message (text)
      - read (boolean)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on chats table
    - Add policies for chat participants
*/

-- Create chats table
CREATE TABLE IF NOT EXISTS chats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid REFERENCES users(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  message text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;

-- Policies for chats
CREATE POLICY "Chat participants can read messages"
  ON chats
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = sender_id OR 
    auth.uid() = recipient_id
  );

CREATE POLICY "Users can send messages"
  ON chats
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_id
      AND (
        bookings.user_id IN (sender_id, recipient_id) OR
        EXISTS (
          SELECT 1 FROM vehicles
          WHERE vehicles.id = bookings.vehicle_id
          AND vehicles.owner_id IN (sender_id, recipient_id)
        )
      )
    )
  );

CREATE POLICY "Recipients can mark messages as read"
  ON chats
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = recipient_id)
  WITH CHECK (auth.uid() = recipient_id);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chats_sender_id ON chats(sender_id);
CREATE INDEX IF NOT EXISTS idx_chats_recipient_id ON chats(recipient_id);
CREATE INDEX IF NOT EXISTS idx_chats_booking_id ON chats(booking_id);
CREATE INDEX IF NOT EXISTS idx_chats_created_at ON chats(created_at);

-- Function to mark messages as read
CREATE OR REPLACE FUNCTION mark_messages_read(
  p_chat_ids uuid[]
) RETURNS void AS $$
BEGIN
  UPDATE chats
  SET 
    read = true,
    updated_at = now()
  WHERE id = ANY(p_chat_ids)
  AND recipient_id = auth.uid()
  AND NOT read;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get unread message count
CREATE OR REPLACE FUNCTION get_unread_message_count(
  p_user_id uuid
) RETURNS integer AS $$
DECLARE
  v_count integer;
BEGIN
  SELECT COUNT(*)
  INTO v_count
  FROM chats
  WHERE recipient_id = p_user_id
  AND NOT read;
  
  RETURN v_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;