import 'react-native-url-polyfill/auto';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthProvider } from './src/components/AuthProvider';
import HomeScreen from './src/screens/HomeScreen';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import VehicleListScreen from './src/screens/VehicleListScreen';
import VehicleDetailsScreen from './src/screens/VehicleDetailsScreen';
import BookingScreen from './src/screens/BookingScreen';
import UserProfileScreen from './src/screens/UserProfileScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <AuthProvider>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen 
            name="Home" 
            component={HomeScreen}
            options={{ title: 'DriveMate' }}
          />
          <Stack.Screen 
            name="Login" 
            component={LoginScreen}
            options={{ title: 'Giriş Yap' }}
          />
          <Stack.Screen 
            name="Register" 
            component={RegisterScreen}
            options={{ title: 'Kayıt Ol' }}
          />
          <Stack.Screen 
            name="VehicleList" 
            component={VehicleListScreen}
            options={{ title: 'Araçlar' }}
          />
          <Stack.Screen 
            name="VehicleDetails" 
            component={VehicleDetailsScreen}
            options={{ title: 'Araç Detayı' }}
          />
          <Stack.Screen 
            name="Booking" 
            component={BookingScreen}
            options={{ title: 'Rezervasyon' }}
          />
          <Stack.Screen 
            name="Profile" 
            component={UserProfileScreen}
            options={{ title: 'Profilim' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
}